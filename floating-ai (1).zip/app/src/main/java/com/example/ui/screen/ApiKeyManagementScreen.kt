package com.example.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.model.ApiKeyEntity
import com.example.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiKeyManagementScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val state by viewModel.uiState.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var editKeyEntity by remember { mutableStateOf<ApiKeyEntity?>(null) }
    var testResultMsg by remember { mutableStateOf<String?>(null) }
    var testSuccess by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Manage API Credentials", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    FloatingActionButton(
                        onClick = { showAddDialog = true },
                        modifier = Modifier.size(40.dp),
                        containerColor = MaterialTheme.colorScheme.primary
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Key")
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                "Your API keys are encrypted locally using Android KeyStore AES-GCM. We never transmit credentials to third-party servers.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))

            if (state.apiKeys.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Key, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No API Keys Configured", style = MaterialTheme.typography.titleMedium)
                        Text("Add OpenAI, Claude, Gemini, or DeepSeek credentials to start chatting.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(onClick = { showAddDialog = true }) {
                            Icon(Icons.Default.Add, null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Add First API Key")
                        }
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(state.apiKeys) { key ->
                        ApiKeyCard(
                            key = key,
                            onSetActive = { viewModel.setActiveApiKey(key.id) },
                            onEdit = { editKeyEntity = key },
                            onDelete = { viewModel.deleteApiKey(key.id) },
                            onTest = {
                                val decKey = viewModel.getDecryptedKey(key)
                                viewModel.testApiKey(key.provider, decKey, key.endpoint.takeIf { it.isNotBlank() }) { success, msg ->
                                    testSuccess = success
                                    testResultMsg = "${key.name}: $msg"
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (showAddDialog || editKeyEntity != null) {
        val isEdit = editKeyEntity != null
        var aiName by remember { mutableStateOf(editKeyEntity?.name ?: "") }
        var apiKeyInput by remember { mutableStateOf("") }
        var provider by remember { mutableStateOf(editKeyEntity?.provider ?: "OpenAI") }
        var endpoint by remember { mutableStateOf(editKeyEntity?.endpoint ?: "") }
        var providerExpanded by remember { mutableStateOf(false) }
        var keyVisible by remember { mutableStateOf(false) }
        var dialogError by remember { mutableStateOf<String?>(null) }
        var isTesting by remember { mutableStateOf(false) }

        val providers = listOf("OpenAI", "Claude", "Gemini", "DeepSeek", "Custom")

        AlertDialog(
            onDismissRequest = {
                showAddDialog = false
                editKeyEntity = null
            },
            title = { Text(if (isEdit) "Edit Credential" else "Add New API Key", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ExposedDropdownMenuBox(
                        expanded = providerExpanded,
                        onExpandedChange = { providerExpanded = !providerExpanded }
                    ) {
                        OutlinedTextField(
                            value = provider,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("AI Provider") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = providerExpanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = providerExpanded, onDismissRequest = { providerExpanded = false }) {
                            providers.forEach { p ->
                                DropdownMenuItem(text = { Text(p) }, onClick = { provider = p; providerExpanded = false })
                            }
                        }
                    }

                    OutlinedTextField(
                        value = aiName,
                        onValueChange = { aiName = it },
                        label = { Text("Custom Nickname (e.g., ChatGPT, My Claude)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = { apiKeyInput = it },
                        label = { Text(if (isEdit) "New API Key (Leave blank to keep current)" else "API Key Secret") },
                        visualTransformation = if (keyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { keyVisible = !keyVisible }) {
                                Icon(if (keyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = endpoint,
                        onValueChange = { endpoint = it },
                        label = { Text("Custom Endpoint URL (Optional)") },
                        placeholder = { Text("https://api.openai.com/v1/chat/completions") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    dialogError?.let {
                        Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }

                    OutlinedButton(
                        onClick = {
                            val k = if (isEdit && apiKeyInput.isBlank()) viewModel.getDecryptedKey(editKeyEntity!!) else apiKeyInput
                            if (k.isBlank()) { dialogError = "Please enter an API Key to test"; return@OutlinedButton }
                            isTesting = true
                            dialogError = null
                            viewModel.testApiKey(provider, k, endpoint.takeIf { it.isNotBlank() }) { success, msg ->
                                isTesting = false
                                dialogError = (if (success) "✅ " else "❌ ") + msg
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isTesting) CircularProgressIndicator(modifier = Modifier.size(16.dp))
                        else Text("Test Connection")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (aiName.isBlank()) { dialogError = "Nickname cannot be empty"; return@Button }
                    if (!isEdit && apiKeyInput.isBlank()) { dialogError = "API Key secret required"; return@Button }

                    if (isEdit) {
                        viewModel.updateApiKey(editKeyEntity!!.copy(name = aiName, provider = provider, endpoint = endpoint), apiKeyInput.takeIf { it.isNotBlank() })
                        editKeyEntity = null
                    } else {
                        viewModel.saveApiKey(aiName, apiKeyInput, provider, endpoint, { showAddDialog = false }) { dialogError = it }
                    }
                }) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false; editKeyEntity = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    testResultMsg?.let { res ->
        AlertDialog(
            onDismissRequest = { testResultMsg = null },
            title = { Text(if (testSuccess) "Connection Verified" else "Test Failed") },
            text = { Text(res) },
            confirmButton = { Button(onClick = { testResultMsg = null }) { Text("OK") } }
        )
    }
}

@Composable
fun ApiKeyCard(key: ApiKeyEntity, onSetActive: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit, onTest: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (key.isActive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = key.isActive, onClick = onSetActive)
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(key.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("${key.provider} • Encrypted (AES-GCM)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (key.isActive) {
                    Surface(color = MaterialTheme.colorScheme.primary, shape = RoundedCornerShape(12.dp)) {
                        Text("Active", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                TextButton(onClick = onTest) { Text("Test") }
                TextButton(onClick = onEdit) { Text("Edit") }
                TextButton(onClick = onDelete, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Delete") }
            }
        }
    }
}
