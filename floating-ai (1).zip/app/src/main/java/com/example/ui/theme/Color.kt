package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Grid Purple & Lavender Palette
val BentoPrimary = Color(0xFF6750A4)
val BentoOnPrimary = Color(0xFFFFFFFF)
val BentoPrimaryContainer = Color(0xFFEADDFF)
val BentoOnPrimaryContainer = Color(0xFF21005D)

val BentoSecondaryContainer = Color(0xFFE8DEF8)
val BentoOnSecondaryContainer = Color(0xFF1D192B)

val BentoTertiary = Color(0xFFD0BCFF)
val BentoOnTertiary = Color(0xFF381E72)

val BentoBackgroundLight = Color(0xFFF3F4F9)
val BentoSurfaceLight = Color(0xFFFFFFFF)
val BentoTextPrimaryLight = Color(0xFF1B1B1F)
val BentoTextSecondaryLight = Color(0xFF44474E)
val BentoBorderLight = Color(0xFFE5E7EB)

val BentoBackgroundDark = Color(0xFF141218)
val BentoSurfaceDark = Color(0xFF1D1B20)
val BentoSurfaceVariantDark = Color(0xFF2B2930)
val BentoTextPrimaryDark = Color(0xFFE6E1E5)
val BentoTextSecondaryDark = Color(0xFFCAC4D0)

val UserBubbleBlue = Color(0xFF6750A4)
val AiBubbleGrayDark = Color(0xFF2B2930)
val AiBubbleGrayLight = Color(0xFFE8DEF8)
