package com.example.data.repository

import android.content.Context
import com.example.data.AppDatabase
import com.example.data.model.ApiKeyEntity
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.network.AiApiClient
import com.example.util.SecurityUtil
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map

class ChatRepository(context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val apiKeyDao = db.apiKeyDao()
    private val chatDao = db.chatDao()

    val allApiKeys: Flow<List<ApiKeyEntity>> = apiKeyDao.getAllKeys()
    val activeApiKeyFlow: Flow<ApiKeyEntity?> = apiKeyDao.getActiveKeyFlow()
    val allChatSessions: Flow<List<ChatSession>> = chatDao.getAllSessions()

    fun searchSessions(query: String): Flow<List<ChatSession>> = chatDao.searchSessions(query)
    fun getMessagesForSession(sessionId: Int): Flow<List<ChatMessage>> = chatDao.getMessagesForSession(sessionId)

    suspend fun saveApiKey(name: String, rawKey: String, provider: String, endpoint: String): Result<Unit> {
        try {
            val (encrypted, iv) = SecurityUtil.encrypt(rawKey)
            val isFirst = apiKeyDao.getActiveKey() == null
            val entity = ApiKeyEntity(
                name = name.trim(),
                encryptedKey = encrypted,
                iv = iv,
                endpoint = endpoint.trim(),
                provider = provider,
                isActive = isFirst
            )
            apiKeyDao.insertKey(entity)
            return Result.success(Unit)
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }

    suspend fun updateApiKey(entity: ApiKeyEntity, newRawKey: String?) {
        if (!newRawKey.isNullOrBlank()) {
            val (encrypted, iv) = SecurityUtil.encrypt(newRawKey)
            apiKeyDao.updateKey(entity.copy(encryptedKey = encrypted, iv = iv))
        } else {
            apiKeyDao.updateKey(entity)
        }
    }

    suspend fun deleteApiKey(id: Int) {
        apiKeyDao.deleteKeyById(id)
    }

    suspend fun setActiveApiKey(id: Int) {
        apiKeyDao.setAsActive(id)
    }

    fun getDecryptedKey(entity: ApiKeyEntity): String {
        return SecurityUtil.decrypt(entity.encryptedKey, entity.iv)
    }

    suspend fun testApiKey(provider: String, rawKey: String, endpoint: String?): Result<String> {
        return AiApiClient.testConnection(provider, rawKey, endpoint)
    }

    suspend fun createNewSession(title: String, aiName: String, provider: String, topic: String = "Chat"): Int {
        val session = ChatSession(title = title, aiName = aiName, provider = provider, topic = topic)
        return chatDao.insertSession(session).toInt()
    }

    suspend fun sendMessage(sessionId: Int, userText: String): Result<ChatMessage> {
        val activeKeyEntity = apiKeyDao.getActiveKey()
            ?: return Result.failure(Exception("No active API key. Please configure one in Settings."))
        
        val rawKey = getDecryptedKey(activeKeyEntity)
        if (rawKey.isEmpty()) {
            return Result.failure(Exception("Failed to decrypt API key credentials."))
        }

        // Insert user message
        val userMsg = ChatMessage(sessionId = sessionId, isUser = true, text = userText)
        chatDao.insertMessage(userMsg)

        // Get history for context
        val history = chatDao.getMessagesList(sessionId)

        // Call API
        val replyResult = AiApiClient.sendMessage(
            provider = activeKeyEntity.provider,
            apiKey = rawKey,
            customEndpoint = activeKeyEntity.endpoint.takeIf { it.isNotBlank() },
            history = history.dropLast(1), // exclude the one we just added since sendMessage takes newMessage separately
            newMessage = userText
        )

        replyResult.onSuccess { replyText ->
            val aiMsg = ChatMessage(sessionId = sessionId, isUser = false, text = replyText)
            val aiMsgId = chatDao.insertMessage(aiMsg)
            return Result.success(aiMsg.copy(id = aiMsgId.toInt()))
        }.onFailure { err ->
            return Result.failure(err)
        }
        return Result.failure(Exception("Unknown error"))
    }

    suspend fun deleteSession(sessionId: Int) = chatDao.deleteSession(sessionId)
    suspend fun deleteMessage(messageId: Int) = chatDao.deleteMessage(messageId)
    suspend fun clearAllChats() = chatDao.clearAllSessions()
}
