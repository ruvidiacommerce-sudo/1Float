package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "api_keys")
data class ApiKeyEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val encryptedKey: String,
    val iv: String,
    val endpoint: String = "",
    val provider: String = "OpenAI", // OpenAI, Claude, Gemini, DeepSeek, Custom
    val isActive: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
