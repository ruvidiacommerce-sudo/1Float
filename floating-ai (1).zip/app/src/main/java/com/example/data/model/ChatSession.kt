package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_sessions")
data class ChatSession(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val aiName: String,
    val provider: String = "OpenAI",
    val topic: String = "General Chat",
    val createdAt: Long = System.currentTimeMillis()
)
