package com.example.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.data.repository.ChatRepository
import com.example.ui.screen.FloatingChatOverlayScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.PreferencesUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

class FloatingChatService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {
    private lateinit var windowManager: WindowManager
    private var composeView: ComposeView? = null
    private lateinit var prefs: PreferencesUtil
    private lateinit var repository: ChatRepository
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = PreferencesUtil(this)
        repository = ChatRepository(this)

        showFloatingWindow()
    }

    private fun showFloatingWindow() {
        val initialWidth = prefs.windowWidthDp.coerceIn(240, 500)
        val initialHeight = prefs.windowHeightDp.coerceIn(320, 800)

        val layoutParams = WindowManager.LayoutParams(
            dpToPx(initialWidth),
            dpToPx(initialHeight),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dpToPx(prefs.windowXDp)
            y = dpToPx(prefs.windowYDp)
        }

        composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingChatService)
            setViewTreeViewModelStoreOwner(this@FloatingChatService)
            setViewTreeSavedStateRegistryOwner(this@FloatingChatService)

            setContent {
                var isMinimized by remember { mutableStateOf(false) }
                val isDark by remember { mutableStateOf(prefs.isDarkMode) }

                MyApplicationTheme(darkTheme = isDark, dynamicColor = false) {
                    FloatingChatOverlayScreen(
                        repository = repository,
                        prefs = prefs,
                        isMinimized = isMinimized,
                        onToggleMinimize = {
                            isMinimized = !isMinimized
                            if (isMinimized) {
                                layoutParams.width = dpToPx(68)
                                layoutParams.height = dpToPx(68)
                                val screenWidth = resources.displayMetrics.widthPixels
                                layoutParams.x = if (layoutParams.x > screenWidth / 2) screenWidth - dpToPx(76) else dpToPx(8)
                            } else {
                                layoutParams.width = dpToPx(prefs.windowWidthDp)
                                layoutParams.height = dpToPx(prefs.windowHeightDp)
                            }
                            windowManager.updateViewLayout(this@apply, layoutParams)
                        },
                        onClose = {
                            stopSelf()
                        },
                        onDrag = { dx, dy ->
                            layoutParams.x += dx.toInt()
                            layoutParams.y += dy.toInt()
                            prefs.windowXDp = pxToDp(layoutParams.x)
                            prefs.windowYDp = pxToDp(layoutParams.y)
                            windowManager.updateViewLayout(this@apply, layoutParams)
                        },
                        onResize = { newWidthDp, newHeightDp ->
                            prefs.windowWidthDp = newWidthDp.coerceIn(240, 600)
                            prefs.windowHeightDp = newHeightDp.coerceIn(300, 850)
                            layoutParams.width = dpToPx(prefs.windowWidthDp)
                            layoutParams.height = dpToPx(prefs.windowHeightDp)
                            windowManager.updateViewLayout(this@apply, layoutParams)
                        }
                    )
                }
            }
        }

        windowManager.addView(composeView, layoutParams)
    }

    private fun dpToPx(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()
    private fun pxToDp(px: Int): Int = (px / resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
        serviceScope.cancel()
        composeView?.let {
            if (it.isAttachedToWindow) {
                windowManager.removeView(it)
            }
        }
    }
}
