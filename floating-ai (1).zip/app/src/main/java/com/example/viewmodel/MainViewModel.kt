package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ApiKeyEntity
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.data.repository.ChatRepository
import com.example.util.PreferencesUtil
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MainUiState(
    val apiKeys: List<ApiKeyEntity> = emptyList(),
    val activeKey: ApiKeyEntity? = null,
    val chatSessions: List<ChatSession> = emptyList(),
    val activeSessionId: Int = -1,
    val currentMessages: List<ChatMessage> = emptyList(),
    val isTyping: Boolean = false,
    val errorMessage: String? = null,
    val searchQuery: String = "",
    val isDarkMode: Boolean = true,
    val windowOpacity: Float = 0.92f,
    val autoLaunch: Boolean = false,
    val notifications: Boolean = true,
    val hasCompletedPermissions: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ChatRepository(application)
    private val prefs = PreferencesUtil(application)

    private val _searchQuery = MutableStateFlow("")
    private val _activeSessionId = MutableStateFlow(prefs.activeSessionId)
    private val _isTyping = MutableStateFlow(false)
    private val _errorMessage = MutableStateFlow<String?>(null)

    private val _isDarkMode = MutableStateFlow(prefs.isDarkMode)
    private val _windowOpacity = MutableStateFlow(prefs.windowOpacity)
    private val _autoLaunch = MutableStateFlow(prefs.autoLaunchOnAppOpen)
    private val _notifications = MutableStateFlow(prefs.notificationsEnabled)
    private val _hasPermissions = MutableStateFlow(prefs.hasCompletedPermissions)

    val currentMessagesFlow: StateFlow<List<ChatMessage>> = _activeSessionId.flatMapLatest { sId ->
        if (sId != -1) repository.getMessagesForSession(sId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sessionsFlow = _searchQuery.flatMapLatest { query ->
        if (query.isBlank()) repository.allChatSessions else repository.searchSessions(query)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val uiState: StateFlow<MainUiState> = combine(
        repository.allApiKeys,
        repository.activeApiKeyFlow,
        sessionsFlow,
        currentMessagesFlow,
        _activeSessionId
    ) { keys, active, sessions, msgs, sId ->
        MainUiState(
            apiKeys = keys,
            activeKey = active,
            chatSessions = sessions,
            activeSessionId = sId,
            currentMessages = msgs,
            searchQuery = _searchQuery.value,
            isTyping = _isTyping.value,
            errorMessage = _errorMessage.value,
            isDarkMode = _isDarkMode.value,
            windowOpacity = _windowOpacity.value,
            autoLaunch = _autoLaunch.value,
            notifications = _notifications.value,
            hasCompletedPermissions = _hasPermissions.value
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MainUiState())

    fun completePermissions() {
        prefs.hasCompletedPermissions = true
        _hasPermissions.value = true
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectSession(sessionId: Int) {
        prefs.activeSessionId = sessionId
        _activeSessionId.value = sessionId
    }

    fun startNewChat(title: String = "New Chat") {
        viewModelScope.launch {
            val activeKey = repository.activeApiKeyFlow.stateIn(viewModelScope).value
            val aiName = activeKey?.name ?: "AI Assistant"
            val provider = activeKey?.provider ?: "OpenAI"
            val id = repository.createNewSession(title, aiName, provider)
            selectSession(id)
        }
    }

    fun sendMessage(text: String) {
        val cleanText = text.trim()
        if (cleanText.isEmpty()) return

        viewModelScope.launch {
            _errorMessage.value = null
            var sId = _activeSessionId.value
            if (sId == -1) {
                val activeKey = repository.activeApiKeyFlow.stateIn(viewModelScope).value
                val aiName = activeKey?.name ?: "AI Assistant"
                val provider = activeKey?.provider ?: "OpenAI"
                val title = cleanText.take(24) + if (cleanText.length > 24) "..." else ""
                sId = repository.createNewSession(title, aiName, provider)
                selectSession(sId)
            }

            _isTyping.value = true
            val result = repository.sendMessage(sId, cleanText)
            _isTyping.value = false

            result.onFailure { err ->
                _errorMessage.value = err.message ?: "Failed to get AI response"
            }
        }
    }

    fun saveApiKey(name: String, key: String, provider: String, endpoint: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val res = repository.saveApiKey(name, key, provider, endpoint)
            res.onSuccess { onSuccess() }.onFailure { onError(it.message ?: "Failed to save key") }
        }
    }

    fun updateApiKey(entity: ApiKeyEntity, newRawKey: String?) {
        viewModelScope.launch {
            repository.updateApiKey(entity, newRawKey)
        }
    }

    fun deleteApiKey(id: Int) {
        viewModelScope.launch {
            repository.deleteApiKey(id)
        }
    }

    fun setActiveApiKey(id: Int) {
        viewModelScope.launch {
            repository.setActiveApiKey(id)
        }
    }

    fun getDecryptedKey(entity: ApiKeyEntity): String = repository.getDecryptedKey(entity)

    fun testApiKey(provider: String, key: String, endpoint: String?, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = repository.testApiKey(provider, key, endpoint)
            res.onSuccess { onResult(true, it) }.onFailure { onResult(false, it.message ?: "Connection test failed") }
        }
    }

    fun deleteSession(sessionId: Int) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (_activeSessionId.value == sessionId) {
                selectSession(-1)
            }
        }
    }

    fun clearAllChats() {
        viewModelScope.launch {
            repository.clearAllChats()
            selectSession(-1)
        }
    }

    fun toggleDarkMode(isDark: Boolean) {
        prefs.isDarkMode = isDark
        _isDarkMode.value = isDark
    }

    fun updateOpacity(opacity: Float) {
        prefs.windowOpacity = opacity
        _windowOpacity.value = opacity
    }

    fun toggleAutoLaunch(enabled: Boolean) {
        prefs.autoLaunchOnAppOpen = enabled
        _autoLaunch.value = enabled
    }

    fun toggleNotifications(enabled: Boolean) {
        prefs.notificationsEnabled = enabled
        _notifications.value = enabled
    }

    fun dismissError() {
        _errorMessage.value = null
    }
}
