package com.example.network

import com.example.data.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object AiApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    suspend fun sendMessage(
        provider: String,
        apiKey: String,
        customEndpoint: String?,
        history: List<ChatMessage>,
        newMessage: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val cleanKey = apiKey.trim()
            if (cleanKey.isEmpty()) {
                return@withContext Result.failure(Exception("API Key is empty. Please verify your stored credentials."))
            }

            when (provider.uppercase()) {
                "CLAUDE", "ANTHROPIC" -> sendClaudeRequest(cleanKey, customEndpoint, history, newMessage)
                "GEMINI", "GOOGLE" -> sendGeminiRequest(cleanKey, customEndpoint, history, newMessage)
                "DEEPSEEK" -> sendOpenAiCompatibleRequest("deepseek-chat", cleanKey, customEndpoint ?: "https://api.deepseek.com/chat/completions", history, newMessage)
                else -> sendOpenAiCompatibleRequest("gpt-4o-mini", cleanKey, customEndpoint ?: "https://api.openai.com/v1/chat/completions", history, newMessage)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun sendOpenAiCompatibleRequest(
        defaultModel: String,
        apiKey: String,
        url: String,
        history: List<ChatMessage>,
        newMessage: String
    ): Result<String> {
        val messagesArray = JSONArray()
        history.takeLast(12).forEach { msg ->
            val role = if (msg.isUser) "user" else "assistant"
            messagesArray.put(JSONObject().apply {
                put("role", role)
                put("content", msg.text)
            })
        }
        messagesArray.put(JSONObject().apply {
            put("role", "user")
            put("content", newMessage)
        })

        val jsonBody = JSONObject().apply {
            put("model", defaultModel)
            put("messages", messagesArray)
        }

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(jsonBody.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        client.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                val errorMsg = try {
                    JSONObject(bodyStr).optJSONObject("error")?.optString("message") ?: "HTTP ${response.code}"
                } catch (e: Exception) { "HTTP error ${response.code}" }
                return Result.failure(Exception("API Error: $errorMsg"))
            }
            val json = JSONObject(bodyStr)
            val choices = json.optJSONArray("choices")
            if (choices != null && choices.length() > 0) {
                val reply = choices.getJSONObject(0).optJSONObject("message")?.optString("content") ?: ""
                return Result.success(reply.trim())
            }
            return Result.failure(Exception("Empty response received from server."))
        }
    }

    private fun sendClaudeRequest(
        apiKey: String,
        customEndpoint: String?,
        history: List<ChatMessage>,
        newMessage: String
    ): Result<String> {
        val url = customEndpoint?.takeIf { it.isNotBlank() } ?: "https://api.anthropic.com/v1/messages"
        val messagesArray = JSONArray()
        history.takeLast(12).forEach { msg ->
            val role = if (msg.isUser) "user" else "assistant"
            messagesArray.put(JSONObject().apply {
                put("role", role)
                put("content", msg.text)
            })
        }
        messagesArray.put(JSONObject().apply {
            put("role", "user")
            put("content", newMessage)
        })

        val jsonBody = JSONObject().apply {
            put("model", "claude-3-5-sonnet-20241022")
            put("max_tokens", 1024)
            put("messages", messagesArray)
        }

        val request = Request.Builder()
            .url(url)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(jsonBody.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        client.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                val errorMsg = try {
                    JSONObject(bodyStr).optJSONObject("error")?.optString("message") ?: "HTTP ${response.code}"
                } catch (e: Exception) { "HTTP error ${response.code}" }
                return Result.failure(Exception("Claude Error: $errorMsg"))
            }
            val json = JSONObject(bodyStr)
            val contentArr = json.optJSONArray("content")
            if (contentArr != null && contentArr.length() > 0) {
                val reply = contentArr.getJSONObject(0).optString("text")
                return Result.success(reply.trim())
            }
            return Result.failure(Exception("Empty response from Claude API."))
        }
    }

    private fun sendGeminiRequest(
        apiKey: String,
        customEndpoint: String?,
        history: List<ChatMessage>,
        newMessage: String
    ): Result<String> {
        val url = customEndpoint?.takeIf { it.isNotBlank() }
            ?: "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"
        val contentsArray = JSONArray()
        history.takeLast(12).forEach { msg ->
            val role = if (msg.isUser) "user" else "model"
            contentsArray.put(JSONObject().apply {
                put("role", role)
                put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
            })
        }
        contentsArray.put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().put("text", newMessage)))
        })

        val jsonBody = JSONObject().apply {
            put("contents", contentsArray)
        }

        val request = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .post(jsonBody.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        client.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                val errorMsg = try {
                    JSONObject(bodyStr).optJSONObject("error")?.optString("message") ?: "HTTP ${response.code}"
                } catch (e: Exception) { "HTTP error ${response.code}" }
                return Result.failure(Exception("Gemini Error: $errorMsg"))
            }
            val json = JSONObject(bodyStr)
            val candidates = json.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val content = candidates.getJSONObject(0).optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val reply = parts.getJSONObject(0).optString("text")
                    return Result.success(reply.trim())
                }
            }
            return Result.failure(Exception("Empty response from Gemini API."))
        }
    }

    suspend fun testConnection(provider: String, apiKey: String, endpoint: String?): Result<String> {
        return sendMessage(provider, apiKey, endpoint, emptyList(), "Reply with 'Connection verified!'")
    }
}
