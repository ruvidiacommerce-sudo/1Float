package com.example.util

import android.content.Context
import android.content.SharedPreferences

class PreferencesUtil(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("floating_ai_prefs_v1", Context.MODE_PRIVATE)

    var hasCompletedPermissions: Boolean
        get() = prefs.getBoolean("has_completed_permissions", false)
        set(value) = prefs.edit().putBoolean("has_completed_permissions", value).apply()

    var windowWidthDp: Int
        get() = prefs.getInt("window_width", 320)
        set(value) = prefs.edit().putInt("window_width", value).apply()

    var windowHeightDp: Int
        get() = prefs.getInt("window_height", 460)
        set(value) = prefs.edit().putInt("window_height", value).apply()

    var windowXDp: Int
        get() = prefs.getInt("window_x", 40)
        set(value) = prefs.edit().putInt("window_x", value).apply()

    var windowYDp: Int
        get() = prefs.getInt("window_y", 100)
        set(value) = prefs.edit().putInt("window_y", value).apply()

    var isDarkMode: Boolean
        get() = prefs.getBoolean("is_dark_mode", true)
        set(value) = prefs.edit().putBoolean("is_dark_mode", value).apply()

    var windowOpacity: Float
        get() = prefs.getFloat("window_opacity", 0.92f)
        set(value) = prefs.edit().putFloat("window_opacity", value).apply()

    var autoLaunchOnAppOpen: Boolean
        get() = prefs.getBoolean("auto_launch", false)
        set(value) = prefs.edit().putBoolean("auto_launch", value).apply()

    var notificationsEnabled: Boolean
        get() = prefs.getBoolean("notifications", true)
        set(value) = prefs.edit().putBoolean("notifications", value).apply()

    var activeSessionId: Int
        get() = prefs.getInt("active_session_id", -1)
        set(value) = prefs.edit().putInt("active_session_id", value).apply()
}
