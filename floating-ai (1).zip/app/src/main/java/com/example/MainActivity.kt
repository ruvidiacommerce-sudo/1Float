package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screen.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val state by viewModel.uiState.collectAsState()

            MyApplicationTheme(darkTheme = state.isDarkMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    if (!state.hasCompletedPermissions) {
                        PermissionScreen(onCompleted = { viewModel.completePermissions() })
                    } else {
                        val navController = rememberNavController()

                        NavHost(navController = navController, startDestination = "home") {
                            composable("home") {
                                HomeScreen(
                                    viewModel = viewModel,
                                    onAddKey = { navController.navigate("api_keys") },
                                    onManageKeys = { navController.navigate("api_keys") },
                                    onChatHistory = { navController.navigate("history") },
                                    onSettings = { navController.navigate("settings") }
                                )
                            }
                            composable("api_keys") {
                                ApiKeyManagementScreen(
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                            composable("history") {
                                ChatHistoryScreen(
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                            composable("settings") {
                                SettingsScreen(
                                    viewModel = viewModel,
                                    onBack = { navController.popBackStack() },
                                    onManageKeys = { navController.navigate("api_keys") }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
