// render.js — turns quest data + engine state into DOM
window.Render = (function () {

  const TRACK_META = {
    html: { name: "Ember Coast", sub: "HTML", quests: () => window.HTML_QUESTS },
    css: { name: "Teal Reef", sub: "CSS", quests: () => window.CSS_QUESTS },
    js: { name: "Violet Peaks", sub: "JavaScript", quests: () => window.JS_QUESTS }
  };

  function el(tag, attrs, children) {
    const node = document.createElement(tag);
    if (attrs) {
      for (const k in attrs) {
        if (k === "class") node.className = attrs[k];
        else if (k === "text") node.textContent = attrs[k];
        else if (k === "html") node.innerHTML = attrs[k];
        else node.setAttribute(k, attrs[k]);
      }
    }
    (children || []).forEach(c => c && node.appendChild(c));
    return node;
  }

  function renderTopbar() {
    const xp = window.Engine.getXp();
    const level = window.Engine.levelForXp(xp);
    const { current, needed } = window.Engine.xpIntoLevel(xp);
    document.getElementById("playerLevel").textContent = level;
    document.getElementById("xpText").textContent = current + " / " + needed + " XP";
    document.getElementById("xpBarFill").style.width = Math.min(100, (current / needed) * 100) + "%";
    document.getElementById("badgesCount").textContent = "\u2605 " + window.Engine.getBadges().length;
  }

  const TIER_META = {
    small: { label: "Small", color: "var(--ok)" },
    medium: { label: "Medium", color: "var(--gold)" },
    large: { label: "Large", color: "var(--html-c)" },
    giant: { label: "Giant", color: "var(--js-c)" }
  };

  function renderSidebar(activeId, onSelect) {
    const wrap = document.querySelector(".sidebar-scroll");
    wrap.innerHTML = "";

    Object.keys(TRACK_META).forEach(track => {
      const meta = TRACK_META[track];
      const quests = meta.quests();
      const doneCount = quests.filter(q => window.Engine.isComplete(q.id)).length;

      const territory = el("div", { class: "territory", "data-track": track });
      territory.appendChild(el("div", { class: "territory-head" }, [
        el("span", { class: "territory-dot" }),
        el("span", { class: "territory-name", text: meta.name }),
        el("span", { class: "territory-sub", text: doneCount + "/" + quests.length })
      ]));

      const trail = el("div", { class: "trail" });
      quests.forEach(q => {
        const complete = window.Engine.isComplete(q.id);
        const unlocked = window.Engine.isUnlocked(q);
        const isCurrent = q.id === activeId;
        const cls = ["quest-node"];
        if (complete) cls.push("complete");
        if (isCurrent) cls.push("current");
        if (!unlocked) cls.push("locked");

        const node = el("button", { class: cls.join(" ") }, [
          el("span", { text: q.order + ". " + q.title })
        ]);
        if (complete) node.appendChild(el("span", { class: "node-check", text: "done" }));
        else if (!unlocked) node.appendChild(el("span", { class: "node-lock", text: "locked" }));

        if (unlocked) {
          node.addEventListener("click", () => onSelect(q.id));
        }
        trail.appendChild(node);
      });

      territory.appendChild(trail);
      wrap.appendChild(territory);
    });

    // Field Projects — always unlocked, self-checked
    const projTerritory = el("div", { class: "territory", "data-track": "projects" });
    const doneProjects = window.PROJECTS.filter(p => window.Engine.isProjectComplete(p.id)).length;
    projTerritory.appendChild(el("div", { class: "territory-head" }, [
      el("span", { class: "territory-dot", style: "background:var(--gold);box-shadow:0 0 8px var(--gold);" }),
      el("span", { class: "territory-name", text: "Field Projects" }),
      el("span", { class: "territory-sub", text: doneProjects + "/" + window.PROJECTS.length })
    ]));
    const projTrail = el("div", { class: "trail" });
    window.PROJECTS.forEach(p => {
      const complete = window.Engine.isProjectComplete(p.id);
      const isCurrent = p.id === activeId;
      const cls = ["quest-node"];
      if (complete) cls.push("complete");
      if (isCurrent) cls.push("current");
      const node = el("button", { class: cls.join(" ") }, [
        el("span", { text: "[" + TIER_META[p.tier].label + "] " + p.title })
      ]);
      if (complete) node.appendChild(el("span", { class: "node-check", text: "done" }));
      node.addEventListener("click", () => onSelect(p.id));
      projTrail.appendChild(node);
    });
    projTerritory.appendChild(projTrail);
    wrap.appendChild(projTerritory);
  }

  function findProject(id) {
    return window.PROJECTS.find(p => p.id === id);
  }

  function renderProject(project, callbacks) {
    const content = document.getElementById("content");
    content.innerHTML = "";

    const saved = window.Engine.getProjectState(project);
    const tier = TIER_META[project.tier];

    content.appendChild(el("span", { class: "quest-eyebrow", style: "color:" + tier.color, text: tier.label.toUpperCase() + " PROJECT \u00b7 " + project.xp + " XP" }));
    content.appendChild(el("h1", { class: "quest-title", text: project.title }));
    content.appendChild(el("p", { class: "quest-intro", text: project.pitch }));

    if (saved.completed) {
      content.appendChild(el("div", { class: "finish-badge", text: "\u2713 Completed" }));
    }

    const tagRow = el("div", { style: "margin-bottom:20px;" });
    project.concepts.forEach(c => {
      tagRow.appendChild(el("span", { class: "callout", style: "display:inline-block;padding:4px 10px;margin:0 6px 6px 0;font-size:12px;", text: c }));
    });
    content.appendChild(tagRow);

    content.appendChild(el("div", { class: "section-label", text: "Requirements Checklist" }));
    const checklist = el("div", { class: "challenge-box", style: "margin-top:8px;padding-top:0;border-top:none;" });
    project.requirements.forEach((req, i) => {
      const row = el("label", { style: "display:flex;align-items:center;gap:10px;padding:8px 0;font-size:14px;color:var(--text-mid);cursor:pointer;" });
      const cb = el("input", { type: "checkbox" });
      cb.checked = !!saved.checklist[i];
      cb.addEventListener("change", () => callbacks.onToggle(i));
      row.appendChild(cb);
      row.appendChild(el("span", { text: req }));
      checklist.appendChild(row);
    });
    content.appendChild(checklist);

    content.appendChild(el("div", { class: "section-label", text: "Build It" }));
    const workbenchMount = el("div");
    content.appendChild(workbenchMount);
    window.WorkbenchEditor.mountProject(workbenchMount, project, saved, callbacks.onCodeChange);

    const footer = el("div", { class: "quest-footer" });
    const backBtn = el("button", { class: "nav-btn", text: "\u2190 Back to Map" });
    backBtn.addEventListener("click", callbacks.onWelcome);
    footer.appendChild(backBtn);
    content.appendChild(footer);
  }

  function renderWelcome(onStart) {
    const content = document.getElementById("content");
    content.innerHTML = "";

    const hero = el("div", { class: "welcome-hero" }, [
      el("h1", { text: "Chart the map. Learn the web." }),
      el("p", { text: "Three territories, twenty-four quests: Ember Coast (HTML), Teal Reef (CSS), and Violet Peaks (JavaScript). Every quest teaches one idea, then makes you build it for real before you can move on." })
    ]);
    content.appendChild(hero);

    const cards = el("div", { class: "territory-cards" });
    Object.keys(TRACK_META).forEach(track => {
      const meta = TRACK_META[track];
      const first = meta.quests()[0];
      const done = meta.quests().filter(q => window.Engine.isComplete(q.id)).length;
      const card = el("div", { class: "tcard", "data-track": track }, [
        el("h3", { text: meta.name }),
        el("p", { text: meta.sub + " \u00b7 " + done + "/" + meta.quests().length + " quests complete" }),
        el("button", { text: done > 0 ? "Continue \u2192" : "Begin \u2192" })
      ]);
      card.querySelector("button").addEventListener("click", () => onStart(firstIncomplete(track) || first.id));
      cards.appendChild(card);
    });
    content.appendChild(cards);

    content.appendChild(el("div", { class: "section-label", text: "Field Projects — build real things" }));
    const projDone = window.PROJECTS.filter(p => window.Engine.isProjectComplete(p.id)).length;
    const projCard = el("div", { class: "tcard", style: "border-top:3px solid var(--gold);max-width:520px;" }, [
      el("h3", { text: "Small \u2192 Giant, 8 self-checked builds" }),
      el("p", { text: projDone + "/" + window.PROJECTS.length + " shipped \u00b7 To-Do List and Color Generator (small) up through a full Memory Match game and Portfolio Site (giant). Always unlocked — jump in whenever quest ideas need a real project to land in." }),
      el("button", { text: "Browse Projects \u2192" })
    ]);
    projCard.querySelector("button").addEventListener("click", () => onStart(window.PROJECTS[0].id));
    content.appendChild(projCard);
  }

  function firstIncomplete(track) {
    const q = TRACK_META[track].quests().find(q => !window.Engine.isComplete(q.id));
    return q ? q.id : null;
  }

  function findQuest(id) {
    return window.Engine.allQuests().find(q => q.id === id);
  }

  function renderContentBlock(block) {
    if (block.type === "p") return el("p", { text: block.text, style: "margin-bottom:14px;color:var(--text-mid);" });
    if (block.type === "example") return el("pre", { class: "example-block", text: block.code });
    if (block.type === "callout") return el("div", { class: "callout", text: block.text });
    return null;
  }

  function renderQuest(quest, callbacks) {
    const content = document.getElementById("content");
    content.innerHTML = "";

    const trackLabel = quest.track === "html" ? "Ember Coast" : quest.track === "css" ? "Teal Reef" : "Violet Peaks";
    content.appendChild(el("span", { class: "quest-eyebrow " + quest.track, text: trackLabel + " \u00b7 Quest " + quest.order + " \u00b7 " + quest.xp + " XP" }));
    content.appendChild(el("h1", { class: "quest-title", text: quest.title }));
    content.appendChild(el("p", { class: "quest-intro", text: quest.intro }));

    if (window.Engine.isComplete(quest.id)) {
      content.appendChild(el("div", { class: "finish-badge", text: "\u2713 Completed" }));
    }

    (quest.content || []).forEach(block => {
      const node = renderContentBlock(block);
      if (node) content.appendChild(node);
    });

    content.appendChild(el("div", { class: "section-label", text: "Practice" }));
    const challengeBox = el("div", { class: "challenge-box" }, [
      el("div", { class: "challenge-title", text: "Your Turn" }),
      el("div", { class: "challenge-desc", text: quest.challenge.description })
    ]);
    const workbenchMount = el("div");
    challengeBox.appendChild(workbenchMount);
    content.appendChild(challengeBox);

    window.WorkbenchEditor.mount(workbenchMount, quest, () => callbacks.onPass(quest));

    const footer = el("div", { class: "quest-footer" });
    const prevQuest = prevOf(quest);
    const nextQuest = nextOf(quest);
    const prevBtn = el("button", { class: "nav-btn", text: "\u2190 Previous" });
    if (prevQuest) prevBtn.addEventListener("click", () => callbacks.onNav(prevQuest.id));
    else prevBtn.setAttribute("disabled", "true");

    const nextBtn = el("button", { class: "nav-btn primary", text: nextQuest ? "Next Quest \u2192" : "Finish Territory \u2192" });
    nextBtn.addEventListener("click", () => {
      if (nextQuest) callbacks.onNav(nextQuest.id);
      else callbacks.onWelcome();
    });
    if (nextQuest && !window.Engine.isUnlocked(nextQuest)) {
      nextBtn.setAttribute("disabled", "true");
      nextBtn.title = "Complete this quest first";
    }

    footer.appendChild(prevBtn);
    footer.appendChild(nextBtn);
    content.appendChild(footer);
  }

  function prevOf(quest) {
    const track = TRACK_META[quest.track].quests();
    return track.find(q => q.order === quest.order - 1) || null;
  }
  function nextOf(quest) {
    const track = TRACK_META[quest.track].quests();
    return track.find(q => q.order === quest.order + 1) || null;
  }

  function showToast(message) {
    const toast = document.getElementById("toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => toast.classList.remove("show"), 2600);
  }

  return { renderTopbar, renderSidebar, renderWelcome, renderQuest, findQuest, findProject, renderProject, showToast };
})();
