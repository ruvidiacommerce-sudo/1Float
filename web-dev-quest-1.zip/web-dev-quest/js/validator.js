// validator.js — checks HTML/CSS challenge code against required patterns.
// (JS challenges are validated live in a sandboxed iframe — see editor.js)
window.Validator = (function () {

  function checkPatterns(code, checks) {
    for (const check of checks) {
      if (!check.pattern.test(code)) {
        return { pass: false, message: check.hint };
      }
    }
    return { pass: true, message: "All checks passed — nice work!" };
  }

  function checkHtml(code, quest) {
    return checkPatterns(code, quest.challenge.checks);
  }

  function checkCss(code, quest) {
    return checkPatterns(code, quest.challenge.checks);
  }

  return { checkHtml, checkCss };
})();
