// app.js — entry point, ties the sidebar, content view, and progress engine together
(function () {

  function navigate(id) {
    if (id.indexOf("proj-") === 0) showProject(id);
    else showQuest(id);
  }

  function showQuest(id) {
    const quest = window.Render.findQuest(id);
    if (!quest) return showWelcome();
    if (!window.Engine.isUnlocked(quest)) return showQuest(firstIncompleteAnywhere() || id);

    window.Engine.setCurrent(id);
    window.Render.renderSidebar(id, navigate);
    window.Render.renderQuest(quest, {
      onPass: handlePass,
      onNav: showQuest,
      onWelcome: showWelcome
    });
    window.Render.renderTopbar();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function showProject(id) {
    const project = window.Render.findProject(id);
    if (!project) return showWelcome();

    window.Engine.setCurrent(id);
    window.Render.renderSidebar(id, navigate);
    window.Render.renderProject(project, {
      onToggle: (index) => handleProjectToggle(project, index),
      onCodeChange: (files) => window.Engine.saveProjectCode(project, files),
      onWelcome: showWelcome
    });
    window.Render.renderTopbar();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleProjectToggle(project, index) {
    const result = window.Engine.toggleProjectChecklistItem(project, index);
    window.Render.renderTopbar();
    window.Render.renderSidebar(project.id, navigate);
    if (result.completedNow) {
      window.Render.showToast("\u2605 Project shipped! +" + result.xpGained + " XP");
    }
  }

  function showWelcome() {
    window.Engine.setCurrent("");
    window.Render.renderSidebar("", navigate);
    window.Render.renderWelcome(navigate);
    window.Render.renderTopbar();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handlePass(quest) {
    const result = window.Engine.completeQuest(quest);
    window.Render.renderTopbar();
    window.Render.renderSidebar(quest.id, navigate);
    if (result.alreadyDone) return;
    if (result.newBadge) {
      window.Render.showToast("\u2605 Territory complete! +" + result.xpGained + " XP and a badge earned.");
    } else {
      window.Render.showToast("+" + result.xpGained + " XP — quest complete!");
    }
  }

  function firstIncompleteAnywhere() {
    const all = window.Engine.allQuests();
    const q = all.find(q => !window.Engine.isComplete(q.id) && window.Engine.isUnlocked(q));
    return q ? q.id : null;
  }

  function init() {
    document.getElementById("resetBtn").addEventListener("click", () => {
      if (confirm("Reset all quest progress, XP, and badges? This can't be undone.")) {
        window.Engine.reset();
        showWelcome();
      }
    });

    const current = window.Engine.getCurrent();
    const hasProgress = window.Engine.getXp() > 0;
    if (current && hasProgress) {
      navigate(current);
    } else {
      showWelcome();
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
