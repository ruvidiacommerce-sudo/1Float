// projects-data.js — "Field Projects": self-checked real builds, small to giant.
// Unlike quests, these aren't auto-graded — you build the whole thing and
// tick off your own requirements checklist as you go.
window.PROJECTS = [
  {
    id: "proj-todo",
    tier: "small",
    title: "Interactive To-Do List",
    pitch: "Add, complete, and delete tasks — the classic first real app.",
    concepts: ["DOM", "Events", "Arrays"],
    xp: 60,
    requirements: [
      "Typing a task and clicking Add puts it on the list",
      "Each task can be marked complete (e.g. a strikethrough style)",
      "Each task can be deleted",
      "The list updates instantly with no page reload"
    ],
    starter: {
      html: "<div class=\"app\">\n  <h1>My Tasks</h1>\n  <div class=\"input-row\">\n    <input id=\"taskInput\" type=\"text\" placeholder=\"Add a task...\">\n    <button id=\"addBtn\">Add</button>\n  </div>\n  <ul id=\"taskList\"></ul>\n</div>",
      css: "body { font-family: sans-serif; padding: 24px; background: #f7f7f7; }\n.app { max-width: 380px; margin: 0 auto; background: #fff; padding: 20px; border-radius: 10px; }\n.input-row { display: flex; gap: 8px; margin: 12px 0; }\n.input-row input { flex: 1; padding: 8px; }",
      js: "const input = document.getElementById('taskInput');\nconst addBtn = document.getElementById('addBtn');\nconst list = document.getElementById('taskList');\n\n// your code here: add, complete, and delete tasks\n"
    }
  },
  {
    id: "proj-palette",
    tier: "small",
    title: "Color Palette Generator",
    pitch: "Generate random color swatches and reveal their hex codes.",
    concepts: ["DOM", "Events", "Flexbox/Grid"],
    xp: 60,
    requirements: [
      "Clicking \"Generate\" shows 5 new random colors",
      "Each swatch displays its hex code as text",
      "Clicking a swatch highlights or copies its hex code",
      "The swatches are laid out with Flexbox or Grid"
    ],
    starter: {
      html: "<div class=\"app\">\n  <h1>Palette Generator</h1>\n  <button id=\"genBtn\">Generate</button>\n  <div id=\"palette\" class=\"palette\"></div>\n</div>",
      css: "body { font-family: sans-serif; padding: 24px; }\n.palette { display: flex; gap: 10px; margin-top: 16px; }\n.swatch { width: 80px; height: 80px; border-radius: 8px; display: flex; align-items: flex-end; justify-content: center; color: #fff; font-size: 11px; padding-bottom: 4px; cursor: pointer; }",
      js: "const genBtn = document.getElementById('genBtn');\nconst palette = document.getElementById('palette');\n\nfunction randomHex() {\n  return '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');\n}\n\n// your code here: on click, render 5 swatches using randomHex()\n"
    }
  },
  {
    id: "proj-quiz",
    tier: "medium",
    title: "Multiple-Choice Quiz App",
    pitch: "Step through questions, track score, and show a final result screen.",
    concepts: ["Arrays of objects", "DOM", "State"],
    xp: 90,
    requirements: [
      "Shows one question at a time from an array of question objects",
      "Clicking an answer shows whether it was correct",
      "Score increases for correct answers",
      "A final screen shows the total score out of the number of questions"
    ],
    starter: {
      html: "<div class=\"app\">\n  <div id=\"quiz\"></div>\n</div>",
      css: "body { font-family: sans-serif; padding: 24px; }\n.app { max-width: 420px; margin: 0 auto; }\n.option { display: block; width: 100%; text-align: left; padding: 10px; margin: 6px 0; border: 1px solid #ccc; border-radius: 6px; background: #fff; cursor: pointer; }",
      js: "const questions = [\n  { q: \"2 + 2 = ?\", options: [\"3\", \"4\", \"5\"], answer: \"4\" },\n  { q: \"Capital of France?\", options: [\"Berlin\", \"Paris\", \"Rome\"], answer: \"Paris\" },\n  { q: \"HTML stands for?\", options: [\"Hyper Trainer\", \"HyperText Markup Language\", \"Home Tool\"], answer: \"HyperText Markup Language\" }\n];\nlet current = 0;\nlet score = 0;\n\n// your code here: render questions[current], handle clicks, advance, show final score\n"
    }
  },
  {
    id: "proj-expenses",
    tier: "medium",
    title: "Expense Tracker",
    pitch: "Log expenses with a running total that survives a page refresh.",
    concepts: ["DOM", "Arrays", "localStorage"],
    xp: 90,
    requirements: [
      "Can add an expense with a name and an amount",
      "The running total updates automatically",
      "Expenses can be deleted",
      "Expenses are still there after refreshing the page (localStorage)"
    ],
    starter: {
      html: "<div class=\"app\">\n  <h1>Expenses</h1>\n  <input id=\"name\" placeholder=\"Expense name\">\n  <input id=\"amount\" type=\"number\" placeholder=\"Amount\">\n  <button id=\"addBtn\">Add</button>\n  <p>Total: $<span id=\"total\">0</span></p>\n  <ul id=\"list\"></ul>\n</div>",
      css: "body { font-family: sans-serif; padding: 24px; }\n.app { max-width: 380px; margin: 0 auto; }",
      js: "// your code here:\n// 1. load saved expenses from localStorage.getItem('expenses') (or start empty)\n// 2. add/delete expenses and re-render the list + total\n// 3. save back with localStorage.setItem('expenses', JSON.stringify(list))\n"
    }
  },
  {
    id: "proj-kanban",
    tier: "large",
    title: "Drag-and-Drop Kanban Board",
    pitch: "A To Do / Doing / Done board where cards drag between columns and the board remembers itself.",
    concepts: ["Drag & Drop events", "localStorage", "Dynamic DOM"],
    xp: 130,
    requirements: [
      "Has at least 3 columns (e.g. To Do, Doing, Done)",
      "Cards can be dragged from one column to another",
      "New cards can be added to a column",
      "The board's state persists after a page refresh (localStorage)"
    ],
    starter: {
      html: "<div class=\"board\">\n  <div class=\"column\" data-col=\"todo\"><h3>To Do</h3><div class=\"cards\"></div><button class=\"add-card\">+ Add card</button></div>\n  <div class=\"column\" data-col=\"doing\"><h3>Doing</h3><div class=\"cards\"></div><button class=\"add-card\">+ Add card</button></div>\n  <div class=\"column\" data-col=\"done\"><h3>Done</h3><div class=\"cards\"></div><button class=\"add-card\">+ Add card</button></div>\n</div>",
      css: "body { font-family: sans-serif; padding: 20px; }\n.board { display: flex; gap: 12px; }\n.column { flex: 1; background: #f4f4f4; padding: 10px; border-radius: 8px; min-height: 220px; }\n.card { background: #fff; padding: 8px; margin: 6px 0; border-radius: 6px; box-shadow: 0 1px 2px rgba(0,0,0,0.15); cursor: grab; }",
      js: "// your code here:\n// 1. make .card elements draggable=true\n// 2. handle dragstart (remember which card), dragover (allow drop), drop (move it into the .cards of the target column)\n// 3. wire up each .add-card button to prompt() a card title and append it\n// 4. save/load column contents with localStorage\n"
    }
  },
  {
    id: "proj-catalog",
    tier: "large",
    title: "Product Catalog with Filters & Cart",
    pitch: "A filterable, sortable product grid with a working shopping cart total.",
    concepts: ["Array.filter/sort", "DOM", "State management"],
    xp: 130,
    requirements: [
      "Displays a grid of products from an array of data",
      "Products can be filtered by category",
      "Products can be sorted by price",
      "Items can be added to and removed from a cart with a running total"
    ],
    starter: {
      html: "<div class=\"app\">\n  <div class=\"filters\">\n    <select id=\"category\"></select>\n    <select id=\"sort\">\n      <option value=\"asc\">Price: Low to High</option>\n      <option value=\"desc\">Price: High to Low</option>\n    </select>\n  </div>\n  <div id=\"grid\" class=\"grid\"></div>\n  <div class=\"cart\"><h3>Cart ($<span id=\"cartTotal\">0</span>)</h3><ul id=\"cartList\"></ul></div>\n</div>",
      css: "body { font-family: sans-serif; padding: 20px; }\n.grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin: 16px 0; }\n.product { border: 1px solid #ddd; border-radius: 8px; padding: 10px; }",
      js: "const products = [\n  { id: 1, name: \"Notebook\", price: 6, category: \"Stationery\" },\n  { id: 2, name: \"Headphones\", price: 45, category: \"Electronics\" },\n  { id: 3, name: \"Water Bottle\", price: 12, category: \"Home\" },\n  { id: 4, name: \"Mouse\", price: 20, category: \"Electronics\" },\n  { id: 5, name: \"Desk Lamp\", price: 28, category: \"Home\" }\n];\nlet cart = [];\n\n// your code here: render products, wire up the category/sort selects, and manage the cart\n"
    }
  },
  {
    id: "proj-memory",
    tier: "giant",
    title: "Memory Match Game",
    pitch: "A full card-flipping memory game: shuffle, match, count moves, win, restart.",
    concepts: ["Game state", "Arrays/shuffle", "Timers", "CSS transforms"],
    xp: 180,
    requirements: [
      "A grid of face-down cards that flip when clicked",
      "Matching pairs stay revealed; non-matching pairs flip back",
      "Tracks the number of moves",
      "Shows a \"You Win\" message when all pairs are matched, with a Restart button"
    ],
    starter: {
      html: "<div class=\"app\">\n  <h1>Memory Match</h1>\n  <p>Moves: <span id=\"moves\">0</span></p>\n  <div id=\"board\" class=\"mem-board\"></div>\n  <button id=\"restart\">Restart</button>\n  <p id=\"winMsg\"></p>\n</div>",
      css: "body { font-family: sans-serif; padding: 20px; text-align: center; }\n.mem-board { display: grid; grid-template-columns: repeat(4, 64px); gap: 8px; justify-content: center; margin: 16px auto; }\n.mem-card { width: 64px; height: 64px; background: #333; color: #fff; display: flex; align-items: center; justify-content: center; cursor: pointer; border-radius: 8px; font-size: 22px; user-select: none; }\n.mem-card.flipped, .mem-card.matched { background: #4FB0A8; }",
      js: "const symbols = ['\ud83c\udf4e','\ud83c\udf4c','\ud83c\udf47','\ud83c\udf49','\ud83c\udf4e','\ud83c\udf4c','\ud83c\udf47','\ud83c\udf49'];\n\n// your code here:\n// 1. shuffle symbols and render 8 face-down .mem-card divs\n// 2. on click, reveal the symbol; when 2 are revealed, check for a match\n// 3. matched pairs stay revealed (add .matched); mismatches flip back after a short delay\n// 4. count moves, detect when all pairs are matched, show winMsg, wire up #restart\n"
    }
  },
  {
    id: "proj-portfolio",
    tier: "giant",
    title: "Personal Portfolio Site",
    pitch: "A full one-page site: hero, about, projects, contact form, responsive nav, and a theme toggle.",
    concepts: ["Semantic HTML", "Responsive CSS", "Forms", "localStorage"],
    xp: 180,
    requirements: [
      "A responsive nav that links to each section on the page",
      "A hero section, an about section, and a projects section with at least 3 items",
      "A contact form with labeled fields and basic validation",
      "A dark/light theme toggle that remembers your choice (localStorage)",
      "Layout holds up from a narrow mobile width to a wide desktop width"
    ],
    starter: {
      html: "<nav>\n  <a href=\"#hero\">Home</a>\n  <a href=\"#about\">About</a>\n  <a href=\"#projects\">Projects</a>\n  <a href=\"#contact\">Contact</a>\n  <button id=\"themeToggle\">\ud83c\udf19</button>\n</nav>\n<section id=\"hero\"><h1>Hi, I'm ...</h1><p>Building things for the web.</p></section>\n<section id=\"about\"><h2>About</h2><p>Write a couple sentences about yourself here.</p></section>\n<section id=\"projects\">\n  <h2>Projects</h2>\n  <div class=\"project-grid\"></div>\n</section>\n<section id=\"contact\">\n  <h2>Contact</h2>\n  <form id=\"contactForm\">\n    <label for=\"cname\">Name</label>\n    <input id=\"cname\" required>\n    <label for=\"cemail\">Email</label>\n    <input id=\"cemail\" type=\"email\" required>\n    <button type=\"submit\">Send</button>\n  </form>\n</section>",
      css: "body { font-family: sans-serif; margin: 0; }\nnav { display: flex; gap: 16px; align-items: center; padding: 16px 24px; position: sticky; top: 0; background: #fff; border-bottom: 1px solid #eee; }\nnav a { text-decoration: none; color: #222; }\nsection { padding: 60px 24px; min-height: 200px; scroll-margin-top: 60px; }\n.project-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; }\n@media (max-width: 600px) { .project-grid { grid-template-columns: 1fr; } nav { flex-wrap: wrap; } }",
      js: "// your code here:\n// 1. render at least 3 items into .project-grid from a JS array\n// 2. wire up #themeToggle to swap a 'dark' class on <body> and save the choice in localStorage\n// 3. add basic validation feedback to #contactForm on submit (prevent default, check fields)\n"
    }
  }
];
