// js-quests.js — "Violet Peaks" territory: JavaScript from zero to master
// Challenge checks run for real in a sandboxed iframe (see editor.js),
// using assert(condition, hintMessage) statements defined in `test`.
window.JS_QUESTS = [
  {
    id: "js-1",
    track: "js",
    order: 1,
    title: "Variables & Types",
    intro: "Variables store data. JavaScript has a small set of core types you'll use constantly.",
    xp: 40,
    content: [
      { type: "p", text: "Use let for values that change, const for values that don't. The core primitive types are string (\"text\"), number (42 or 3.14), and boolean (true/false). typeof tells you a value's type." },
      { type: "example", code: "let score = 10;\nconst playerName = \"Nova\";\nlet isWinner = false;\n\nconsole.log(typeof score); // \"number\"" }
    ],
    challenge: {
      description: "Declare three variables: name (a string), age (a number), and isStudent (a boolean).",
      starter: "let name = \"\";\nlet age = 0;\nlet isStudent = false;\n",
      type: "js",
      test: "assert(typeof name === 'string' && name.length > 0, 'Set name to a non-empty string.');\nassert(typeof age === 'number' && age > 0, 'Set age to a number greater than 0.');\nassert(typeof isStudent === 'boolean', 'isStudent should be true or false.');"
    }
  },
  {
    id: "js-2",
    track: "js",
    order: 2,
    title: "Operators & Conditionals",
    intro: "Make decisions in code with comparisons and if/else branching.",
    xp: 45,
    content: [
      { type: "p", text: "Comparison operators (===, !==, <, >=) produce booleans. if/else picks a branch based on a condition. The ternary operator (cond ? a : b) is a compact one-line if/else." },
      { type: "example", code: "function label(age) {\n  if (age >= 18) {\n    return \"adult\";\n  } else {\n    return \"minor\";\n  }\n}" }
    ],
    challenge: {
      description: "Write a function checkAge(age) that returns \"adult\" if age is 18 or over, otherwise \"minor\".",
      starter: "function checkAge(age) {\n  // your code here\n}\n",
      type: "js",
      test: "assert(checkAge(20) === 'adult', 'checkAge(20) should return \"adult\".');\nassert(checkAge(10) === 'minor', 'checkAge(10) should return \"minor\".');\nassert(checkAge(18) === 'adult', 'checkAge(18) should return \"adult\" (boundary case).');"
    }
  },
  {
    id: "js-3",
    track: "js",
    order: 3,
    title: "Loops",
    intro: "Repeat work without repeating code — the for loop and while loop.",
    xp: 45,
    content: [
      { type: "p", text: "A for loop runs while a condition holds, updating a counter each time: for (let i = 0; i < 10; i++) {}. Use it to accumulate a result across many iterations." },
      { type: "example", code: "let total = 0;\nfor (let i = 1; i <= 5; i++) {\n  total += i;\n}\n// total is 15" }
    ],
    challenge: {
      description: "Use a for loop to sum the numbers from 1 to 10 into a variable called total.",
      starter: "let total = 0;\n// your loop here\n",
      type: "js",
      test: "assert(typeof total === 'number', 'total should be a number.');\nassert(total === 55, 'total should equal 55 (sum of 1 through 10).');"
    }
  },
  {
    id: "js-4",
    track: "js",
    order: 4,
    title: "Functions",
    intro: "Package logic into reusable blocks — the core unit of organization in JavaScript.",
    xp: 45,
    content: [
      { type: "p", text: "A function declaration (function name() {}) can be called before it appears in the file. An arrow function (const name = () => {}) is a shorter, modern syntax, common for short helpers." },
      { type: "example", code: "function add(a, b) {\n  return a + b;\n}\n\nconst multiply = (a, b) => a * b;" }
    ],
    challenge: {
      description: "Write a function add(a, b) that returns their sum, and an arrow function multiply(a, b) that returns their product.",
      starter: "function add(a, b) {\n  // your code here\n}\n\nconst multiply = (a, b) => {\n  // your code here\n};\n",
      type: "js",
      test: "assert(add(2, 3) === 5, 'add(2, 3) should return 5.');\nassert(multiply(4, 5) === 20, 'multiply(4, 5) should return 20.');"
    }
  },
  {
    id: "js-5",
    track: "js",
    order: 5,
    title: "Arrays & Objects",
    intro: "Arrays hold ordered lists; objects hold named properties. Together they model almost any data.",
    xp: 55,
    content: [
      { type: "p", text: "Arrays have powerful built-in methods: .map() transforms every item into a new array, .filter() keeps only items matching a condition. Objects group related values under named keys: { name: \"Ana\", age: 29 }." },
      { type: "example", code: "const nums = [1, 2, 3, 4, 5];\nconst doubled = nums.map(n => n * 2);\nconst evens = nums.filter(n => n % 2 === 0);\n\nconst person = { name: \"Ana\", age: 29 };" }
    ],
    challenge: {
      description: "Given nums = [1,2,3,4,5], create doubled (each number ×2) using .map, and evens (only even numbers) using .filter. Also create an object person with name and age properties.",
      starter: "const nums = [1, 2, 3, 4, 5];\nconst doubled = [];\nconst evens = [];\nconst person = {};\n",
      type: "js",
      test: "assert(Array.isArray(doubled) && doubled.join(',') === '2,4,6,8,10', 'doubled should be [2,4,6,8,10].');\nassert(Array.isArray(evens) && evens.join(',') === '2,4', 'evens should be [2,4].');\nassert(typeof person === 'object' && typeof person.name === 'string' && typeof person.age === 'number', 'person should have a string name and a number age.');"
    }
  },
  {
    id: "js-6",
    track: "js",
    order: 6,
    title: "DOM Manipulation",
    intro: "JavaScript's real power on the web: reading and changing the page itself, live.",
    xp: 55,
    content: [
      { type: "p", text: "document.querySelector(selector) finds an element (same syntax as CSS selectors). Once found, you can read or set its .textContent, or change its .style properties directly." },
      { type: "example", code: "const box = document.querySelector('#box');\nbox.textContent = 'Updated!';\nbox.style.color = 'teal';" }
    ],
    challenge: {
      description: "There's a <div id=\"box\">Hello</div> in the preview. Select it and set its textContent to \"Updated!\".",
      starter: "const box = document.querySelector('#box');\n// your code here\n",
      type: "js",
      domSetup: "<div id=\"box\">Hello</div>",
      test: "assert(document.getElementById('box') && document.getElementById('box').textContent === 'Updated!', 'Set #box textContent to exactly \"Updated!\".');"
    }
  },
  {
    id: "js-7",
    track: "js",
    order: 7,
    title: "Events",
    intro: "Make pages interactive by responding to what people do — clicks, typing, and more.",
    xp: 55,
    content: [
      { type: "p", text: "addEventListener(type, handler) runs a function whenever an event happens, like 'click'. This is how buttons, forms, and every interactive control on the web actually work." },
      { type: "example", code: "const btn = document.querySelector('#btn');\nbtn.addEventListener('click', () => {\n  console.log('clicked!');\n});" }
    ],
    challenge: {
      description: "There's a <button id=\"btn\">Click me</button> and a <p id=\"out\">0</p> in the preview. Add a click listener to the button that sets #out's textContent to \"1\".",
      starter: "const btn = document.querySelector('#btn');\n// your code here\n",
      type: "js",
      domSetup: "<button id=\"btn\">Click me</button>\n<p id=\"out\">0</p>",
      test: "document.getElementById('btn').click();\nassert(document.getElementById('out').textContent === '1', 'Clicking #btn should set #out textContent to \"1\".');"
    }
  },
  {
    id: "js-8",
    track: "js",
    order: 8,
    title: "Classes, Closures & Async",
    intro: "Object blueprints, functions that remember state, and code that waits for things.",
    xp: 65,
    content: [
      { type: "p", text: "A class is a blueprint for creating objects with shared behavior, using a constructor and methods. A closure is a function that 'remembers' variables from the scope it was created in, even after that scope has finished — useful for counters, caches, and private state." },
      { type: "example", code: "class Counter {\n  constructor() {\n    this.count = 0;\n  }\n  increment() {\n    this.count++;\n    return this.count;\n  }\n}\n\nfunction makeCounter() {\n  let count = 0;\n  return function () {\n    count++;\n    return count;\n  };\n}" },
      { type: "callout", text: "Asynchronous code (promises and async/await) lets JavaScript wait for things like network requests without freezing the page: async function load() { const res = await fetch(url); }. It's the standard way to handle anything that takes time." }
    ],
    challenge: {
      description: "Write a class Counter with a constructor that sets count to 0, and a method increment() that adds 1 to count and returns it. Also write a function makeCounter() that returns a closure-based counter function starting at 0.",
      starter: "class Counter {\n  constructor() {\n    // your code here\n  }\n  increment() {\n    // your code here\n  }\n}\n\nfunction makeCounter() {\n  // your code here\n}\n",
      type: "js",
      test: "const c = new Counter();\nassert(c.count === 0, 'Counter should start with count = 0.');\nassert(c.increment() === 1 && c.increment() === 2, 'increment() should increase and return count.');\nconst next = makeCounter();\nassert(typeof next === 'function', 'makeCounter() should return a function.');\nassert(next() === 1 && next() === 2, 'the returned function should count up each call, starting at 1.');"
    }
  },
  {
    id: "js-9",
    track: "js",
    order: 9,
    title: "Promises & Async/Await",
    intro: "Master rank: handle things that take time — timers, and in real apps, network requests — without freezing everything else.",
    xp: 65,
    content: [
      { type: "p", text: "A Promise represents a value that isn't ready yet. async/await is the clean, modern way to work with promises: mark a function async, and inside it you can await a promise as if it were synchronous. The sandbox here provides a helper, wait(ms, value), that returns a promise resolving to value after ms milliseconds — it stands in for a real API call." },
      { type: "example", code: "async function loadUser() {\n  const name = await wait(300, \"Nova\");\n  return name.toUpperCase();\n}\n\nloadUser().then(result => console.log(result)); // \"NOVA\" after 300ms" },
      { type: "callout", text: "In a real app you'd write const res = await fetch(url); const data = await res.json(); — same await pattern, just with a network call instead of a timer." }
    ],
    challenge: {
      description: "Write an async function loadData() that awaits wait(100, \"hello\") and returns the result in uppercase.",
      starter: "async function loadData() {\n  // your code here\n}\n",
      type: "js",
      async: true,
      test: "const result = await loadData();\nassert(result === 'HELLO', 'loadData() should await wait(100, \"hello\") and return it uppercased.');"
    }
  },
  {
    id: "js-10",
    track: "js",
    order: 10,
    title: "Error Handling",
    intro: "Master rank: fail on purpose, on your own terms, instead of letting bugs crash the whole page silently.",
    xp: 55,
    content: [
      { type: "p", text: "throw new Error(\"message\") raises an error deliberately. try/catch lets you run risky code and recover instead of crashing: anything thrown inside try jumps straight to catch, where the error object's .message describes what went wrong." },
      { type: "example", code: "function safeDivide(a, b) {\n  if (b === 0) {\n    throw new Error(\"Cannot divide by zero\");\n  }\n  return a / b;\n}\n\ntry {\n  safeDivide(1, 0);\n} catch (e) {\n  console.log(e.message);\n}" }
    ],
    challenge: {
      description: "Write safeDivide(a, b) that throws new Error(\"Cannot divide by zero\") when b is 0, otherwise returns a / b.",
      starter: "function safeDivide(a, b) {\n  // your code here\n}\n",
      type: "js",
      test: "assert(safeDivide(10, 2) === 5, 'safeDivide(10, 2) should return 5.');\nlet threw = false;\ntry {\n  safeDivide(1, 0);\n} catch (e) {\n  threw = true;\n  assert(e.message === 'Cannot divide by zero', 'The error message should be exactly \"Cannot divide by zero\".');\n}\nassert(threw, 'safeDivide(1, 0) should throw an error.');"
    }
  },
  {
    id: "js-11",
    track: "js",
    order: 11,
    title: "Higher-Order Array Methods",
    intro: "Master rank: reduce and sort — the two array methods that unlock almost any data-crunching task.",
    xp: 60,
    content: [
      { type: "p", text: ".reduce((acc, item) => ..., startValue) collapses an array down to a single value — a sum, a total, a grouped object. .sort((a, b) => a - b) orders an array in place; the compare function decides order (negative means a comes first)." },
      { type: "example", code: "const prices = [3, 25, 8];\nconst total = prices.reduce((sum, p) => sum + p, 0); // 36\n\nconst items = [{ price: 25 }, { price: 3 }];\nitems.sort((a, b) => a.price - b.price); // ascending by price" },
      { type: "callout", text: "In larger apps this logic usually lives in its own file and is shared with import/export (ES modules) — the same idea as functions, just organized across files instead of one." }
    ],
    challenge: {
      description: "Given cart (an array of {name, price} objects), use .reduce to compute totalPrice, and .sort to create sortedByPrice ordered from cheapest to most expensive.",
      starter: "const cart = [\n  { name: \"Pen\", price: 3 },\n  { name: \"Bag\", price: 25 },\n  { name: \"Cup\", price: 8 }\n];\nlet totalPrice = 0;\nlet sortedByPrice = [];\n",
      type: "js",
      test: "assert(totalPrice === 36, 'totalPrice should be 36 (3 + 25 + 8).');\nassert(Array.isArray(sortedByPrice) && sortedByPrice.length === 3, 'sortedByPrice should be an array of 3 items.');\nassert(sortedByPrice[0] && sortedByPrice[0].name === 'Pen' && sortedByPrice[2] && sortedByPrice[2].name === 'Bag', 'sortedByPrice should run cheapest to most expensive: Pen, Cup, Bag.');"
    }
  }
];
