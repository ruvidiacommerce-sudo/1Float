// engine.js — owns all persisted progress state (localStorage-backed)
window.Engine = (function () {
  const STORAGE_KEY = "webDevQuest_progress_v1";

  function defaultState() {
    return {
      xp: 0,
      completed: {},       // { questId: true }
      current: "html-1",
      badges: []            // territory ids fully finished, e.g. "html"
    };
  }

  let state = load();

  function load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultState();
      const parsed = JSON.parse(raw);
      return Object.assign(defaultState(), parsed);
    } catch (e) {
      return defaultState();
    }
  }

  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      // storage unavailable (e.g. private browsing) — fail silently,
      // the session still works, it just won't persist.
    }
  }

  // Level curve: level N requires N * 120 cumulative XP (simple, predictable)
  function levelForXp(xp) {
    let level = 1;
    while (xp >= level * 120) {
      xp -= level * 120;
      level++;
    }
    return level;
  }

  function xpIntoLevel(xp) {
    let level = 1;
    let remaining = xp;
    while (remaining >= level * 120) {
      remaining -= level * 120;
      level++;
    }
    return { current: remaining, needed: level * 120 };
  }

  function allQuests() {
    return [].concat(window.HTML_QUESTS, window.CSS_QUESTS, window.JS_QUESTS);
  }

  function isComplete(questId) {
    return !!state.completed[questId];
  }

  function isUnlocked(quest) {
    if (quest.order === 1) return true;
    const track = quest.track === "html" ? window.HTML_QUESTS
                : quest.track === "css" ? window.CSS_QUESTS
                : window.JS_QUESTS;
    const prev = track.find(q => q.order === quest.order - 1);
    return prev ? isComplete(prev.id) : true;
  }

  function completeQuest(quest) {
    if (state.completed[quest.id]) return { alreadyDone: true };
    state.completed[quest.id] = true;
    state.xp += quest.xp;

    const track = quest.track === "html" ? window.HTML_QUESTS
                : quest.track === "css" ? window.CSS_QUESTS
                : window.JS_QUESTS;
    const trackDone = track.every(q => state.completed[q.id]);
    let newBadge = null;
    if (trackDone && state.badges.indexOf(quest.track) === -1) {
      state.badges.push(quest.track);
      newBadge = quest.track;
    }
    save();
    return { alreadyDone: false, newBadge: newBadge, xpGained: quest.xp };
  }

  function setCurrent(questId) {
    state.current = questId;
    save();
  }

  function getCurrent() {
    return state.current;
  }

  function getBadges() {
    return state.badges.slice();
  }

  function getXp() {
    return state.xp;
  }

  function reset() {
    state = defaultState();
    save();
  }

  return {
    allQuests,
    isComplete,
    isUnlocked,
    completeQuest,
    setCurrent,
    getCurrent,
    getBadges,
    getXp,
    levelForXp,
    xpIntoLevel,
    reset
  };
})();
