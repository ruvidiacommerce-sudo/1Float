// html-quests.js — "Ember Coast" territory: HTML from zero to master
window.HTML_QUESTS = [
  {
    id: "html-1",
    track: "html",
    order: 1,
    title: "The Document Skeleton",
    intro: "Every HTML page starts with the same bones. Learn the skeleton every browser expects before it can render anything.",
    xp: 40,
    content: [
      { type: "p", text: "An HTML document always begins with a doctype declaration, telling the browser to use modern HTML5 rules. After that, everything lives inside a single <html> element, split into <head> (metadata, not shown on the page) and <body> (everything the visitor actually sees)." },
      { type: "example", code: "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"UTF-8\">\n  <title>My Page</title>\n</head>\n<body>\n  <h1>Hello, world!</h1>\n</body>\n</html>" },
      { type: "callout", text: "The <title> tag controls the browser tab text, not anything on the page itself — a common beginner mix-up." }
    ],
    challenge: {
      description: "Build a valid HTML skeleton: doctype, <html> with lang=\"en\", a <head> containing a <title>, and a <body> containing one <h1>.",
      starter: "<!-- write your full HTML skeleton here -->\n",
      type: "html",
      checks: [
        { pattern: /<!DOCTYPE html>/i, hint: "Add <!DOCTYPE html> as the very first line." },
        { pattern: /<html[^>]*lang=/i, hint: "Give the <html> tag a lang attribute, e.g. lang=\"en\"." },
        { pattern: /<head>[\s\S]*<title>[\s\S]*<\/title>[\s\S]*<\/head>/i, hint: "Put a <title>...</title> inside <head>." },
        { pattern: /<body>[\s\S]*<h1>[\s\S]*<\/h1>[\s\S]*<\/body>/i, hint: "Put an <h1>...</h1> inside <body>." }
      ]
    }
  },
  {
    id: "html-2",
    track: "html",
    order: 2,
    title: "Text & Headings",
    intro: "Headings give a page structure and hierarchy — search engines and screen readers both rely on it.",
    xp: 40,
    content: [
      { type: "p", text: "Headings go from <h1> (most important, use once per page) down to <h6>. Paragraphs use <p>. Inside text you can mark words as important with <strong> (bold, semantic emphasis) or <em> (italic, stressed emphasis)." },
      { type: "example", code: "<h1>Page Title</h1>\n<h2>Section</h2>\n<p>This is <strong>important</strong> and this is <em>emphasized</em>.</p>" }
    ],
    challenge: {
      description: "Write an <h1>, an <h2> below it, and a <p> that contains one <strong> word.",
      starter: "",
      type: "html",
      checks: [
        { pattern: /<h1>[\s\S]*<\/h1>/i, hint: "Include an <h1>." },
        { pattern: /<h2>[\s\S]*<\/h2>/i, hint: "Include an <h2>." },
        { pattern: /<p>[\s\S]*<strong>[\s\S]*<\/strong>[\s\S]*<\/p>/i, hint: "Include a <p> with a <strong> word inside it." }
      ]
    }
  },
  {
    id: "html-3",
    track: "html",
    order: 3,
    title: "Links & Images",
    intro: "The web is made of links. Learn how to point to other pages and embed images correctly.",
    xp: 45,
    content: [
      { type: "p", text: "A link is an <a> tag with an href attribute pointing to a destination. An image is an <img> tag — it's self-closing and needs src (the file) and alt (a text description, essential for accessibility)." },
      { type: "example", code: "<a href=\"https://example.com\">Visit Example</a>\n<img src=\"cat.jpg\" alt=\"A sleeping orange cat\">" },
      { type: "callout", text: "alt text isn't optional decoration — screen readers read it aloud, and browsers show it if the image fails to load." }
    ],
    challenge: {
      description: "Create one <a> with an href, and one <img> with both src and alt attributes.",
      starter: "",
      type: "html",
      checks: [
        { pattern: /<a[^>]*href=["'][^"']+["'][^>]*>[\s\S]*<\/a>/i, hint: "Add an <a href=\"...\">link text</a>." },
        { pattern: /<img[^>]*src=["'][^"']+["'][^>]*alt=["'][^"']+["']/i, hint: "Add an <img src=\"...\" alt=\"...\"> (both attributes, alt after src)." }
      ]
    }
  },
  {
    id: "html-4",
    track: "html",
    order: 4,
    title: "Lists & Tables",
    intro: "Group related items with lists, and lay out grid-like data with tables.",
    xp: 45,
    content: [
      { type: "p", text: "Unordered lists (<ul>) use bullets; ordered lists (<ol>) use numbers. Both hold <li> items. Tables use <table>, with rows as <tr> and cells as <td> (or <th> for header cells)." },
      { type: "example", code: "<ul>\n  <li>Milk</li>\n  <li>Eggs</li>\n</ul>\n\n<table>\n  <tr><th>Name</th><th>Age</th></tr>\n  <tr><td>Ana</td><td>29</td></tr>\n</table>" }
    ],
    challenge: {
      description: "Build a <ul> with at least 2 <li> items, and a <table> with at least one <tr> containing two <td> cells.",
      starter: "",
      type: "html",
      checks: [
        { pattern: /<ul>[\s\S]*<li>[\s\S]*<\/li>[\s\S]*<li>[\s\S]*<\/li>[\s\S]*<\/ul>/i, hint: "Add a <ul> with two <li> items." },
        { pattern: /<table>[\s\S]*<tr>[\s\S]*<td>[\s\S]*<\/td>[\s\S]*<td>[\s\S]*<\/td>[\s\S]*<\/tr>[\s\S]*<\/table>/i, hint: "Add a <table> with a <tr> containing two <td> cells." }
      ]
    }
  },
  {
    id: "html-5",
    track: "html",
    order: 5,
    title: "Forms & Inputs",
    intro: "Forms are how pages collect information from people — logins, search boxes, checkout flows.",
    xp: 50,
    content: [
      { type: "p", text: "A <form> wraps input controls. <input> has a type attribute (text, email, password, checkbox...). Always pair an input with a <label> — clicking the label focuses the input, and it's required for accessibility. A <button> submits the form." },
      { type: "example", code: "<form>\n  <label for=\"email\">Email</label>\n  <input type=\"email\" id=\"email\" name=\"email\">\n  <button type=\"submit\">Sign up</button>\n</form>" }
    ],
    challenge: {
      description: "Build a <form> containing a <label for=\"...\"> linked to an <input> with a matching id, plus a submit <button>.",
      starter: "",
      type: "html",
      checks: [
        { pattern: /<form>/i, hint: "Wrap everything in a <form>." },
        { pattern: /<label[^>]*for=["']([\w-]+)["']/i, hint: "Add a <label for=\"someId\">." },
        { pattern: /<input[^>]*id=["']([\w-]+)["']/i, hint: "Add an <input id=\"someId\"> whose id matches the label's for." },
        { pattern: /<button[^>]*>[\s\S]*<\/button>/i, hint: "Add a <button>...</button> to submit the form." }
      ]
    }
  },
  {
    id: "html-6",
    track: "html",
    order: 6,
    title: "Semantic HTML5",
    intro: "Modern HTML describes meaning, not just boxes — this is what makes pages accessible and SEO-friendly.",
    xp: 50,
    content: [
      { type: "p", text: "Instead of wrapping everything in generic <div>s, HTML5 gives you tags that describe their purpose: <header>, <nav>, <main>, <section>, <article>, <footer>. Screen readers and search engines use these to understand your page's structure." },
      { type: "example", code: "<header>\n  <nav>...</nav>\n</header>\n<main>\n  <article>...</article>\n</main>\n<footer>...</footer>" },
      { type: "callout", text: "Rule of thumb: reach for a semantic tag first, and only fall back to <div> when nothing else fits." }
    ],
    challenge: {
      description: "Structure a page using <header>, <main>, and <footer> as top-level regions.",
      starter: "",
      type: "html",
      checks: [
        { pattern: /<header>[\s\S]*<\/header>/i, hint: "Include a <header>." },
        { pattern: /<main>[\s\S]*<\/main>/i, hint: "Include a <main>." },
        { pattern: /<footer>[\s\S]*<\/footer>/i, hint: "Include a <footer>." }
      ]
    }
  },
  {
    id: "html-7",
    track: "html",
    order: 7,
    title: "Attributes, Divs & Data",
    intro: "The generic building blocks: <div>, <span>, class, id, and custom data attributes for hooking up JavaScript.",
    xp: 45,
    content: [
      { type: "p", text: "<div> is a block-level generic container; <span> is inline. class is for styling groups of elements (reusable), id is a unique identifier (one per page). data-* attributes let you attach custom data that JavaScript can read later." },
      { type: "example", code: "<div class=\"card\" id=\"profile-card\" data-user-id=\"42\">\n  <span class=\"badge\">New</span>\n</div>" }
    ],
    challenge: {
      description: "Create a <div> with a class, an id, and a data-* attribute, containing a <span> with its own class.",
      starter: "",
      type: "html",
      checks: [
        { pattern: /<div[^>]*class=["'][^"']+["'][^>]*id=["'][^"']+["'][^>]*data-[\w-]+=["'][^"']*["']/i, hint: "Add a <div class=\"...\" id=\"...\" data-something=\"...\">." },
        { pattern: /<span[^>]*class=["'][^"']+["'][^>]*>[\s\S]*<\/span>/i, hint: "Nest a <span class=\"...\">...</span> inside the div." }
      ]
    }
  },
  {
    id: "html-8",
    track: "html",
    order: 8,
    title: "Multimedia & Embeds",
    intro: "Master rank: embed audio, video, and other pages directly without any plugins.",
    xp: 55,
    content: [
      { type: "p", text: "<video> and <audio> play media natively, with a controls attribute to show playback UI. <iframe> embeds an entire other page (maps, YouTube videos, widgets) inside yours." },
      { type: "example", code: "<video src=\"clip.mp4\" controls></video>\n<audio src=\"song.mp3\" controls></audio>\n<iframe src=\"https://example.com\" title=\"embedded page\"></iframe>" },
      { type: "callout", text: "Always give an <iframe> a title attribute — it's how screen reader users know what the embedded content is." }
    ],
    challenge: {
      description: "Add a <video> with controls, and an <iframe> with both src and title attributes.",
      starter: "",
      type: "html",
      checks: [
        { pattern: /<video[^>]*controls/i, hint: "Add a <video> tag with a controls attribute." },
        { pattern: /<iframe[^>]*src=["'][^"']+["'][^>]*title=["'][^"']+["']/i, hint: "Add an <iframe src=\"...\" title=\"...\">." }
      ]
    }
  }
];
