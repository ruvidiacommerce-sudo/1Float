// css-quests.js — "Teal Reef" territory: CSS from zero to master
window.CSS_QUESTS = [
  {
    id: "css-1",
    track: "css",
    order: 1,
    title: "Selectors & Syntax",
    intro: "CSS rules say which elements to target, and what style to give them. Everything else builds on this.",
    xp: 40,
    content: [
      { type: "p", text: "A CSS rule is a selector followed by declarations in curly braces. Select by element name (p), by class (.name, reusable), or by id (#name, unique). Each declaration is property: value;" },
      { type: "example", code: "p { color: navy; }\n.card { padding: 12px; }\n#logo { width: 80px; }" }
    ],
    challenge: {
      description: "Write three CSS rules: one targeting the element p, one targeting a class .highlight, and one targeting an id #title — each with at least one declaration.",
      starter: "",
      type: "css",
      checks: [
        { pattern: /\bp\s*\{[^}]+\}/i, hint: "Add a rule selecting p { ... }." },
        { pattern: /\.highlight\s*\{[^}]+\}/i, hint: "Add a rule selecting .highlight { ... }." },
        { pattern: /#title\s*\{[^}]+\}/i, hint: "Add a rule selecting #title { ... }." }
      ]
    }
  },
  {
    id: "css-2",
    track: "css",
    order: 2,
    title: "Colors & Units",
    intro: "How CSS measures color and size — and why not all units behave the same way.",
    xp: 40,
    content: [
      { type: "p", text: "Colors: named (red), hex (#ff0000), or rgb(255,0,0). Sizes: px is a fixed pixel; em is relative to the parent's font size; rem is relative to the root font size (more predictable); % is relative to the parent's size." },
      { type: "example", code: ".box {\n  color: #333;\n  background: rgb(240, 240, 240);\n  font-size: 1.2rem;\n  width: 50%;\n}" }
    ],
    challenge: {
      description: "Style a class .box with a hex color, an rgb() background, and a width in rem or %.",
      starter: ".box {\n\n}",
      type: "css",
      checks: [
        { pattern: /\.box\s*\{[^}]*color\s*:\s*#[0-9a-f]{3,6}/i, hint: "Give .box a color using a hex value like #333." },
        { pattern: /\.box\s*\{[^}]*background(-color)?\s*:\s*rgb\(/i, hint: "Give .box a background using rgb(...)." },
        { pattern: /\.box\s*\{[^}]*width\s*:\s*[\d.]+(rem|%)/i, hint: "Give .box a width in rem or %." }
      ]
    }
  },
  {
    id: "css-3",
    track: "css",
    order: 3,
    title: "The Box Model",
    intro: "Every element is a box: content, padding, border, margin. Misunderstanding this causes 90% of layout bugs.",
    xp: 50,
    content: [
      { type: "p", text: "From inside out: content → padding (space inside the border) → border → margin (space outside the border, between elements). box-sizing: border-box makes width/height include padding and border, which is far more predictable than the default." },
      { type: "example", code: ".card {\n  box-sizing: border-box;\n  width: 300px;\n  padding: 16px;\n  border: 1px solid #ccc;\n  margin: 10px;\n}" }
    ],
    challenge: {
      description: "Style .card with box-sizing: border-box, a padding, a border, and a margin.",
      starter: ".card {\n\n}",
      type: "css",
      checks: [
        { pattern: /\.card\s*\{[^}]*box-sizing\s*:\s*border-box/i, hint: "Set box-sizing: border-box;" },
        { pattern: /\.card\s*\{[^}]*padding\s*:/i, hint: "Set a padding." },
        { pattern: /\.card\s*\{[^}]*border\s*:/i, hint: "Set a border." },
        { pattern: /\.card\s*\{[^}]*margin\s*:/i, hint: "Set a margin." }
      ]
    }
  },
  {
    id: "css-4",
    track: "css",
    order: 4,
    title: "Typography",
    intro: "Control how text looks and reads — font, size, weight, alignment, and spacing.",
    xp: 40,
    content: [
      { type: "p", text: "font-family sets the typeface (with fallbacks), font-weight controls boldness (normal/bold/100-900), text-align positions text, and line-height controls vertical spacing between lines of text — crucial for readability." },
      { type: "example", code: "p {\n  font-family: Georgia, serif;\n  font-weight: 400;\n  text-align: center;\n  line-height: 1.6;\n}" }
    ],
    challenge: {
      description: "Style p with a font-family, a font-weight, and a line-height.",
      starter: "p {\n\n}",
      type: "css",
      checks: [
        { pattern: /\bp\s*\{[^}]*font-family\s*:/i, hint: "Set a font-family." },
        { pattern: /\bp\s*\{[^}]*font-weight\s*:/i, hint: "Set a font-weight." },
        { pattern: /\bp\s*\{[^}]*line-height\s*:/i, hint: "Set a line-height." }
      ]
    }
  },
  {
    id: "css-5",
    track: "css",
    order: 5,
    title: "Flexbox",
    intro: "The tool you'll reach for constantly: one-dimensional layout that aligns and distributes space automatically.",
    xp: 55,
    content: [
      { type: "p", text: "display: flex turns a container into a flex row (by default). justify-content aligns children along that row (space-between, center...). align-items aligns them on the cross axis. gap adds space between children without margin hacks." },
      { type: "example", code: ".nav {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  gap: 16px;\n}" }
    ],
    challenge: {
      description: "Style .row as a flex container with justify-content, align-items, and a gap.",
      starter: ".row {\n\n}",
      type: "css",
      checks: [
        { pattern: /\.row\s*\{[^}]*display\s*:\s*flex/i, hint: "Set display: flex;" },
        { pattern: /\.row\s*\{[^}]*justify-content\s*:/i, hint: "Set justify-content." },
        { pattern: /\.row\s*\{[^}]*align-items\s*:/i, hint: "Set align-items." },
        { pattern: /\.row\s*\{[^}]*gap\s*:/i, hint: "Set a gap." }
      ]
    }
  },
  {
    id: "css-6",
    track: "css",
    order: 6,
    title: "CSS Grid",
    intro: "Two-dimensional layout — rows and columns at once — for whole-page or card-grid structures.",
    xp: 55,
    content: [
      { type: "p", text: "display: grid turns a container into a grid. grid-template-columns defines column tracks (e.g. repeat(3, 1fr) for three equal columns). gap adds spacing between grid cells, same as in flexbox." },
      { type: "example", code: ".gallery {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 12px;\n}" }
    ],
    challenge: {
      description: "Style .gallery as a grid with grid-template-columns and a gap.",
      starter: ".gallery {\n\n}",
      type: "css",
      checks: [
        { pattern: /\.gallery\s*\{[^}]*display\s*:\s*grid/i, hint: "Set display: grid;" },
        { pattern: /\.gallery\s*\{[^}]*grid-template-columns\s*:/i, hint: "Set grid-template-columns." },
        { pattern: /\.gallery\s*\{[^}]*gap\s*:/i, hint: "Set a gap." }
      ]
    }
  },
  {
    id: "css-7",
    track: "css",
    order: 7,
    title: "Positioning & Z-Index",
    intro: "Take elements out of normal flow to overlay, pin, or stack them precisely.",
    xp: 50,
    content: [
      { type: "p", text: "position: relative shifts an element from its normal spot without affecting others. position: absolute removes it from flow, positioned relative to its nearest positioned ancestor. position: fixed pins it to the viewport. z-index controls stacking order when elements overlap." },
      { type: "example", code: ".modal {\n  position: fixed;\n  top: 20px;\n  right: 20px;\n  z-index: 100;\n}" }
    ],
    challenge: {
      description: "Style .badge with position: absolute, a top or right offset, and a z-index.",
      starter: ".badge {\n\n}",
      type: "css",
      checks: [
        { pattern: /\.badge\s*\{[^}]*position\s*:\s*absolute/i, hint: "Set position: absolute;" },
        { pattern: /\.badge\s*\{[^}]*(top|right|bottom|left)\s*:/i, hint: "Set an offset like top or right." },
        { pattern: /\.badge\s*\{[^}]*z-index\s*:/i, hint: "Set a z-index." }
      ]
    }
  },
  {
    id: "css-8",
    track: "css",
    order: 8,
    title: "Transitions, Variables & Responsive Design",
    intro: "Master rank: smooth animations, reusable custom properties, and layouts that adapt to any screen.",
    xp: 60,
    content: [
      { type: "p", text: "transition animates property changes smoothly (paired with :hover or JS-driven class changes). CSS variables (--name) store reusable values. Media queries apply rules only under certain conditions, like a max screen width, making layouts responsive." },
      { type: "example", code: ":root { --brand: #4FB0A8; }\n.btn {\n  background: var(--brand);\n  transition: background 0.2s ease;\n}\n.btn:hover { background: #333; }\n\n@media (max-width: 600px) {\n  .btn { width: 100%; }\n}" }
    ],
    challenge: {
      description: "Define a CSS variable in :root, use it with var() in .btn, add a transition, and add a @media (max-width: 600px) rule.",
      starter: ":root {\n\n}\n\n.btn {\n\n}",
      type: "css",
      checks: [
        { pattern: /:root\s*\{[^}]*--[\w-]+\s*:/i, hint: "Define a custom property in :root, like --brand: ...;" },
        { pattern: /\.btn\s*\{[^}]*var\(--[\w-]+\)/i, hint: "Use var(--yourVariable) inside .btn." },
        { pattern: /\.btn\s*\{[^}]*transition\s*:/i, hint: "Add a transition to .btn." },
        { pattern: /@media\s*\([^)]*max-width[^)]*\)\s*\{/i, hint: "Add an @media (max-width: ...) block." }
      ]
    }
  }
];
