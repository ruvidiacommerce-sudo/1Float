// editor.js — the interactive workbench: textarea editor + live preview + grading
window.WorkbenchEditor = (function () {

  // A single generic sandbox body used by every CSS quest's live preview,
  // so whichever selector the lesson teaches has something to style.
  const CSS_DEMO_BODY = [
    "<p>This is a paragraph of body text.</p>",
    "<p class=\"highlight\">This paragraph has the .highlight class.</p>",
    "<h1 id=\"title\">Title Heading (#title)</h1>",
    "<div class=\"box\">.box</div>",
    "<div class=\"card\">.card content</div>",
    "<div class=\"row\"><span>Item A</span><span>Item B</span><span>Item C</span></div>",
    "<div class=\"gallery\"><div>1</div><div>2</div><div>3</div></div>",
    "<div style=\"position:relative;height:70px;background:#eee;margin-top:8px;\"><div class=\"badge\">.badge</div></div>",
    "<button class=\"btn\">.btn button</button>"
  ].join("\n");

  let currentJsCallback = null;

  window.addEventListener("message", function (e) {
    if (e.data && e.data.type === "js-result" && currentJsCallback) {
      currentJsCallback(e.data);
    }
  });

  function el(tag, attrs, children) {
    const node = document.createElement(tag);
    if (attrs) {
      for (const k in attrs) {
        if (k === "class") node.className = attrs[k];
        else if (k === "text") node.textContent = attrs[k];
        else node.setAttribute(k, attrs[k]);
      }
    }
    (children || []).forEach(c => node.appendChild(c));
    return node;
  }

  function mount(container, quest, onPass) {
    container.innerHTML = "";
    const type = quest.challenge.type;

    const workbench = el("div", { class: "workbench" });
    const tabs = el("div", { class: "workbench-tabs" }, [
      el("div", { class: "workbench-tab", text: type === "js" ? "script.js" : type === "css" ? "style.css" : "index.html" })
    ]);

    const panes = el("div", { class: "workbench-panes" });
    const editorPane = el("div", { class: "pane-editor" });
    const textarea = el("textarea", { class: "code-input", spellcheck: "false" });
    textarea.value = quest.challenge.starter || "";
    editorPane.appendChild(textarea);

    const previewPane = el("div", { class: "pane-preview" });
    let iframe = null;
    let consoleBox = null;

    if (type === "js") {
      previewPane.appendChild(el("div", { class: "preview-label", text: "Live Sandbox" }));
      iframe = el("iframe", { class: "preview-frame", style: quest.challenge.domSetup ? "min-height:110px;" : "display:none;" });
      previewPane.appendChild(iframe);
      previewPane.appendChild(el("div", { class: "preview-label", text: "Console" }));
      consoleBox = el("div", { class: "preview-console" });
      previewPane.appendChild(consoleBox);
    } else {
      previewPane.appendChild(el("div", { class: "preview-label", text: "Live Preview" }));
      iframe = el("iframe", { class: "preview-frame" });
      previewPane.appendChild(iframe);
    }

    panes.appendChild(editorPane);
    panes.appendChild(previewPane);

    const actions = el("div", { class: "workbench-actions" });
    const checkBtn = el("button", { class: "btn btn-check", text: "Run Check" });
    const revealBtn = el("button", { class: "btn btn-reveal", text: "Show Example" });
    const resultSpan = el("span", { class: "check-result" });
    actions.appendChild(checkBtn);
    actions.appendChild(revealBtn);
    actions.appendChild(resultSpan);

    workbench.appendChild(tabs);
    workbench.appendChild(panes);
    workbench.appendChild(actions);
    container.appendChild(workbench);

    function renderPreview() {
      const code = textarea.value;
      if (type === "html") {
        iframe.srcdoc = code;
      } else if (type === "css") {
        iframe.srcdoc = "<!DOCTYPE html><html><head><style>" +
          "body{font-family:-apple-system,sans-serif;padding:14px;margin:0;color:#222;}" +
          code +
          "</style></head><body>" + CSS_DEMO_BODY + "</body></html>";
      } else if (type === "js" && quest.challenge.domSetup) {
        iframe.srcdoc = "<!DOCTYPE html><html><head><style>body{font-family:-apple-system,sans-serif;padding:10px;}</style></head><body>" +
          quest.challenge.domSetup + "</body></html>";
      }
    }

    renderPreview();
    textarea.addEventListener("input", () => {
      if (type !== "js") renderPreview();
    });

    revealBtn.addEventListener("click", () => {
      const exampleBlock = (quest.content || []).find(b => b.type === "example");
      if (exampleBlock) {
        textarea.value = exampleBlock.code;
        renderPreview();
      }
    });

    checkBtn.addEventListener("click", () => {
      resultSpan.textContent = "Checking…";
      resultSpan.className = "check-result";

      if (type === "html" || type === "css") {
        renderPreview();
        const result = type === "html"
          ? window.Validator.checkHtml(textarea.value, quest)
          : window.Validator.checkCss(textarea.value, quest);
        showResult(result);
      } else if (type === "js") {
        runJsCheck();
      }
    });

    function runJsCheck() {
      const doc = document.implementation.createHTMLDocument("sandbox");
      // Build via a hidden iframe so it has its own real DOM/window.
      const runFrame = document.createElement("iframe");
      runFrame.style.display = "none";
      document.body.appendChild(runFrame);
      const fdoc = runFrame.contentDocument;
      fdoc.open();
      fdoc.write("<!DOCTYPE html><html><head></head><body>" + (quest.challenge.domSetup || "") + "</body></html>");
      fdoc.close();

      // mirror the same DOM into the visible preview iframe so the
      // learner can see what their code affected
      if (quest.challenge.domSetup) {
        iframe.srcdoc = "<!DOCTYPE html><html><head><style>body{font-family:-apple-system,sans-serif;padding:10px;}</style></head><body>" +
          quest.challenge.domSetup + "</body></html>";
      }

      currentJsCallback = function (data) {
        currentJsCallback = null;
        consoleBox.innerHTML = "";
        (data.logs || []).forEach(line => {
          consoleBox.appendChild(el("div", { class: "log-line", text: line }));
        });
        if (!data.logs || data.logs.length === 0) {
          consoleBox.appendChild(el("div", { class: "log-line", text: "(no console output)" }));
        }
        showResult(data);
        document.body.removeChild(runFrame);
      };

      const harness =
        "(function(){\n" +
        "  var __logs = [];\n" +
        "  var __origLog = console.log;\n" +
        "  console.log = function(){ __logs.push(Array.prototype.slice.call(arguments).map(String).join(' ')); __origLog.apply(console, arguments); };\n" +
        "  window.__failed = null;\n" +
        "  function assert(cond, msg){ if(!cond && !window.__failed){ window.__failed = msg; } }\n" +
        "  try {\n" +
        textarea.value + "\n" +
        quest.challenge.test + "\n" +
        "    parent.postMessage({ type: 'js-result', pass: !window.__failed, message: window.__failed || 'All checks passed — nice work!', logs: __logs }, '*');\n" +
        "  } catch (e) {\n" +
        "    parent.postMessage({ type: 'js-result', pass: false, message: 'Error: ' + e.message, logs: __logs }, '*');\n" +
        "  }\n" +
        "})();";

      const scriptEl = fdoc.createElement("script");
      scriptEl.textContent = harness;
      fdoc.body.appendChild(scriptEl);
    }

    function showResult(result) {
      resultSpan.textContent = result.message;
      resultSpan.className = "check-result " + (result.pass ? "pass" : "fail");
      if (result.pass) onPass();
    }
  }

  return { mount };
})();
