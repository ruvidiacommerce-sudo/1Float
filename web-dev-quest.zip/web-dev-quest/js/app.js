// app.js — entry point, ties the sidebar, content view, and progress engine together
(function () {

  function showQuest(id) {
    const quest = window.Render.findQuest(id);
    if (!quest) return showWelcome();
    if (!window.Engine.isUnlocked(quest)) return showQuest(firstIncompleteAnywhere() || id);

    window.Engine.setCurrent(id);
    window.Render.renderSidebar(id, showQuest);
    window.Render.renderQuest(quest, {
      onPass: handlePass,
      onNav: showQuest,
      onWelcome: showWelcome
    });
    window.Render.renderTopbar();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function showWelcome() {
    window.Engine.setCurrent("");
    window.Render.renderSidebar("", showQuest);
    window.Render.renderWelcome(showQuest);
    window.Render.renderTopbar();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handlePass(quest) {
    const result = window.Engine.completeQuest(quest);
    window.Render.renderTopbar();
    window.Render.renderSidebar(quest.id, showQuest);
    if (result.alreadyDone) return;
    if (result.newBadge) {
      window.Render.showToast("\u2605 Territory complete! +" + result.xpGained + " XP and a badge earned.");
    } else {
      window.Render.showToast("+" + result.xpGained + " XP — quest complete!");
    }
  }

  function firstIncompleteAnywhere() {
    const all = window.Engine.allQuests();
    const q = all.find(q => !window.Engine.isComplete(q.id) && window.Engine.isUnlocked(q));
    return q ? q.id : null;
  }

  function init() {
    document.getElementById("resetBtn").addEventListener("click", () => {
      if (confirm("Reset all quest progress, XP, and badges? This can't be undone.")) {
        window.Engine.reset();
        showWelcome();
      }
    });

    const current = window.Engine.getCurrent();
    const hasProgress = window.Engine.getXp() > 0;
    if (current && hasProgress) {
      showQuest(current);
    } else {
      showWelcome();
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
