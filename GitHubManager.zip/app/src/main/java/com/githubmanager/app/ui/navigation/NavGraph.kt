package com.githubmanager.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.githubmanager.app.ui.editor.FileEditorScreen
import com.githubmanager.app.ui.login.LoginScreen
import com.githubmanager.app.ui.repodetail.RepoDetailScreen
import com.githubmanager.app.ui.repos.ReposListScreen
import com.githubmanager.app.ui.settings.SettingsScreen
import com.githubmanager.app.ui.upload.UploadScreen

@Composable
fun GitHubManagerNavGraph(startDestination: String) {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = startDestination) {

        composable(Routes.LOGIN) {
            LoginScreen(onSignedIn = {
                navController.navigate(Routes.REPOS) { popUpTo(Routes.LOGIN) { inclusive = true } }
            })
        }

        composable(Routes.REPOS) {
            ReposListScreen(
                onOpenRepo = { owner, repo -> navController.navigate(Routes.repoDetail(owner, repo)) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onSignedOut = {
                    navController.navigate(Routes.LOGIN) { popUpTo(0) { inclusive = true } }
                }
            )
        }

        composable(
            route = Routes.REPO_DETAIL,
            arguments = listOf(navArgument("owner") { type = NavType.StringType }, navArgument("repo") { type = NavType.StringType })
        ) { backStackEntry ->
            val owner = backStackEntry.arguments?.getString("owner").orEmpty()
            val repo = backStackEntry.arguments?.getString("repo").orEmpty()
            RepoDetailScreen(
                owner = owner,
                repo = repo,
                onBack = { navController.popBackStack() },
                onOpenFile = { path, branch, sha -> navController.navigate(Routes.fileEditor(owner, repo, path, branch, sha, isNew = false)) },
                onNewFile = { path, branch -> navController.navigate(Routes.fileEditor(owner, repo, path, branch, null, isNew = true)) },
                onUpload = { targetPath, branch -> navController.navigate(Routes.upload(owner, repo, targetPath, branch)) }
            )
        }

        composable(
            route = Routes.FILE_EDITOR,
            arguments = listOf(
                navArgument("owner") { type = NavType.StringType },
                navArgument("repo") { type = NavType.StringType },
                navArgument("path") { type = NavType.StringType; defaultValue = "" },
                navArgument("branch") { type = NavType.StringType; defaultValue = "" },
                navArgument("sha") { type = NavType.StringType; defaultValue = "" },
                navArgument("isNew") { type = NavType.BoolType; defaultValue = false }
            )
        ) { backStackEntry ->
            val args = backStackEntry.arguments
            FileEditorScreen(
                owner = args?.getString("owner").orEmpty(),
                repo = args?.getString("repo").orEmpty(),
                branch = Routes.dec(args?.getString("branch")),
                path = Routes.dec(args?.getString("path")),
                sha = args?.getString("sha")?.takeIf { it.isNotBlank() },
                isNewFile = args?.getBoolean("isNew") ?: false,
                onDone = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.UPLOAD,
            arguments = listOf(
                navArgument("owner") { type = NavType.StringType; defaultValue = "" },
                navArgument("repo") { type = NavType.StringType; defaultValue = "" },
                navArgument("targetPath") { type = NavType.StringType; defaultValue = "" },
                navArgument("branch") { type = NavType.StringType; defaultValue = "" }
            )
        ) { backStackEntry ->
            val args = backStackEntry.arguments
            UploadScreen(
                owner = args?.getString("owner").orEmpty(),
                repo = args?.getString("repo").orEmpty(),
                branch = Routes.dec(args?.getString("branch")),
                targetPath = Routes.dec(args?.getString("targetPath")),
                onDone = { navController.popBackStack() }
            )
        }
    }
}
