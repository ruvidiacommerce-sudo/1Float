package com.githubmanager.app.data.repository

import android.util.Base64
import com.githubmanager.app.data.model.*
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.remote.GitHubApiService
import com.githubmanager.app.data.remote.safeApiCall
import com.githubmanager.app.util.encodeGitPath
import com.githubmanager.app.util.joinPath
import com.githubmanager.app.util.ClipEntry

class ContentsRepository(private val api: GitHubApiService) {

    val treeEngine = GitTreeEngine(api)

    suspend fun listFolder(owner: String, repo: String, path: String, ref: String?): ApiResult<List<ContentItem>> =
        safeApiCall { api.getContents(owner, repo, encodeGitPath(path), ref) }

    suspend fun getFile(owner: String, repo: String, path: String, ref: String?): ApiResult<ContentItem> =
        safeApiCall { api.getContentFile(owner, repo, encodeGitPath(path), ref) }

    suspend fun createOrUpdateFile(
        owner: String, repo: String, path: String, contentBytes: ByteArray,
        message: String, branch: String, existingSha: String? = null
    ): ApiResult<FileCommitResponse> {
        val body = CreateOrUpdateFileRequest(
            message = message,
            content = Base64.encodeToString(contentBytes, Base64.NO_WRAP),
            sha = existingSha,
            branch = branch
        )
        return safeApiCall { api.createOrUpdateFile(owner, repo, encodeGitPath(path), body) }
    }

    suspend fun deleteFile(owner: String, repo: String, path: String, sha: String, message: String, branch: String): ApiResult<FileCommitResponse> =
        safeApiCall { api.deleteFile(owner, repo, encodeGitPath(path), DeleteFileRequest(message, sha, branch)) }

    /** Git has no real folders — a folder is just a common path prefix — so
     *  an empty one is represented by a placeholder file, the same trick
     *  `git` itself has no answer for either. */
    suspend fun createFolder(owner: String, repo: String, path: String, branch: String): ApiResult<FileCommitResponse> {
        val keepPath = "${path.trimEnd('/')}/.gitkeep"
        return createOrUpdateFile(owner, repo, keepPath, ByteArray(0), "Create folder $path", branch)
    }

    suspend fun deleteFolder(owner: String, repo: String, path: String, branch: String): ApiResult<String> {
        val treeResult = treeEngine.getRecursiveTree(owner, repo, branch)
        if (treeResult is ApiResult.Error) return treeResult
        val prefix = "${path.trimEnd('/')}/"
        val toDelete = (treeResult as ApiResult.Success).data.tree
            .filter { it.type == "blob" && (it.path == path || it.path.startsWith(prefix)) }
        if (toDelete.isEmpty()) return ApiResult.Error("That folder is already empty or doesn't exist.")
        val changes = toDelete.map { GitTreeEntry(path = it.path, mode = it.mode, type = "blob", sha = null) }
        return treeEngine.applyTreeChanges(owner, repo, branch, "Delete folder $path", changes)
    }

    /** Moves (renames) a folder, or copies it when [keepOriginal] is true.
     *  Existing blob shas are reused — no file content is re-uploaded. */
    suspend fun moveOrCopyFolder(
        owner: String, repo: String, branch: String,
        fromPath: String, toPath: String, keepOriginal: Boolean
    ): ApiResult<String> {
        val treeResult = treeEngine.getRecursiveTree(owner, repo, branch)
        if (treeResult is ApiResult.Error) return treeResult
        val fromTrimmed = fromPath.trimEnd('/')
        val prefix = "$fromTrimmed/"
        val matches = (treeResult as ApiResult.Success).data.tree
            .filter { it.type == "blob" && (it.path == fromPath || it.path.startsWith(prefix)) }
        if (matches.isEmpty()) return ApiResult.Error("Nothing found at that path.")

        val toTrimmed = toPath.trimEnd('/')
        val changes = mutableListOf<GitTreeEntry>()
        for (entry in matches) {
            val relative = entry.path.removePrefix(fromTrimmed)
            val newPath = (toTrimmed + relative).trimStart('/')
            changes += GitTreeEntry(path = newPath, mode = entry.mode, type = "blob", sha = entry.sha)
            if (!keepOriginal) {
                changes += GitTreeEntry(path = entry.path, mode = entry.mode, type = "blob", sha = null)
            }
        }
        val verb = if (keepOriginal) "Copy" else "Move"
        return treeEngine.applyTreeChanges(owner, repo, branch, "$verb $fromPath to $toPath", changes)
    }

    /** Moves or copies a single file — used by cut/copy/paste and rename. */
    suspend fun moveOrCopySingleFile(
        owner: String, repo: String, branch: String,
        fromPath: String, toPath: String, fileSha: String, mode: String, keepOriginal: Boolean
    ): ApiResult<String> {
        val changes = mutableListOf(GitTreeEntry(path = toPath, mode = mode, type = "blob", sha = fileSha))
        if (!keepOriginal) changes += GitTreeEntry(path = fromPath, mode = mode, type = "blob", sha = null)
        val verb = if (keepOriginal) "Copy" else "Move"
        return treeEngine.applyTreeChanges(owner, repo, branch, "$verb $fromPath to $toPath", changes)
    }

    suspend fun searchFilenames(owner: String, repo: String, branch: String, query: String): ApiResult<List<GitTreeEntry>> {
        val treeResult = treeEngine.getRecursiveTree(owner, repo, branch)
        if (treeResult is ApiResult.Error) return treeResult
        val lower = query.lowercase()
        return ApiResult.Success(
            (treeResult as ApiResult.Success).data.tree.filter { it.type == "blob" && it.path.lowercase().contains(lower) }
        )
    }

    /** Pastes one or more clipboard entries (files and/or folders) into
     *  [targetFolder] as a single commit, regardless of how many files that
     *  expands to — folders are only expanded from a tree listing when at
     *  least one is actually present in the selection. */
    suspend fun pasteEntries(
        owner: String, repo: String, branch: String,
        entries: List<ClipEntry>, targetFolder: String, keepOriginal: Boolean
    ): ApiResult<String> {
        val needsTree = entries.any { it.isFolder }
        val treeEntries: List<GitTreeEntry> = if (needsTree) {
            val treeResult = treeEngine.getRecursiveTree(owner, repo, branch)
            if (treeResult is ApiResult.Error) return treeResult
            (treeResult as ApiResult.Success).data.tree
        } else emptyList()

        val changes = mutableListOf<GitTreeEntry>()
        for (entry in entries) {
            val target = joinPath(targetFolder, entry.name)
            if (entry.isFolder) {
                val fromTrimmed = entry.path.trimEnd('/')
                val prefix = "$fromTrimmed/"
                val matches = treeEntries.filter { it.type == "blob" && (it.path == entry.path || it.path.startsWith(prefix)) }
                for (m in matches) {
                    val relative = m.path.removePrefix(fromTrimmed)
                    val newPath = (target.trimEnd('/') + relative).trimStart('/')
                    changes += GitTreeEntry(path = newPath, mode = m.mode, type = "blob", sha = m.sha)
                    if (!keepOriginal) changes += GitTreeEntry(path = m.path, mode = m.mode, type = "blob", sha = null)
                }
            } else {
                changes += GitTreeEntry(path = target, mode = entry.mode, type = "blob", sha = entry.sha)
                if (!keepOriginal) changes += GitTreeEntry(path = entry.path, mode = entry.mode, type = "blob", sha = null)
            }
        }
        if (changes.isEmpty()) return ApiResult.Error("Nothing to paste.")
        val verb = if (keepOriginal) "Copy" else "Move"
        return treeEngine.applyTreeChanges(owner, repo, branch, "$verb ${entries.size} item(s) to $targetFolder", changes)
    }
}
