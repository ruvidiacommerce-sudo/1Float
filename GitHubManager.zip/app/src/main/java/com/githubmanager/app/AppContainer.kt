package com.githubmanager.app

import android.content.Context
import com.githubmanager.app.data.local.AccountStore
import com.githubmanager.app.data.local.RepoTreeCache
import com.githubmanager.app.data.local.SettingsStore
import com.githubmanager.app.data.remote.GitHubApiService
import com.githubmanager.app.data.remote.RetrofitProvider
import com.githubmanager.app.data.repository.ArtifactRepository
import com.githubmanager.app.data.repository.AuthRepository
import com.githubmanager.app.data.repository.ContentsRepository
import com.githubmanager.app.data.repository.RepoRepository
import com.githubmanager.app.data.repository.UploadRepository
import com.githubmanager.app.data.repository.WorkflowRepository

/** A small hand-wired dependency container. Deliberately not using
 *  Hilt/Dagger here — this project is built exclusively by CI with no local
 *  Android Studio to debug an annotation-processor mismatch, so plain
 *  constructor injection is the more reliable choice. */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val accountStore = AccountStore(appContext)
    val settingsStore = SettingsStore(appContext)
    val treeCache = RepoTreeCache()

    private val api: GitHubApiService by lazy { RetrofitProvider.api(accountStore) }

    val authRepository by lazy { AuthRepository(api, accountStore) }
    val repoRepository by lazy { RepoRepository(api) }
    val contentsRepository by lazy { ContentsRepository(api) }
    val uploadRepository by lazy { UploadRepository(api) }
    val workflowRepository by lazy { WorkflowRepository(api) }
    val artifactRepository by lazy { ArtifactRepository(api) { accountStore.getCachedToken() } }
}
