package com.githubmanager.app.data.local

import com.githubmanager.app.data.model.GitTreeEntry

/**
 * Holds one repo's full recursive file listing in memory so the file browser
 * can search-by-name and jump around instantly instead of re-hitting the
 * API on every navigation. Only ever populated when the
 * "cache repo tree for search" setting is on; otherwise callers simply never
 * write to it and every lookup is a fresh network call. Cleared on process
 * death — this is a speed cache, not a database.
 */
class RepoTreeCache {

    private data class Key(val owner: String, val repo: String, val ref: String)

    private val cache = mutableMapOf<Key, List<GitTreeEntry>>()

    fun get(owner: String, repo: String, ref: String): List<GitTreeEntry>? =
        cache[Key(owner, repo, ref)]

    fun put(owner: String, repo: String, ref: String, entries: List<GitTreeEntry>) {
        cache[Key(owner, repo, ref)] = entries
    }

    fun invalidate(owner: String, repo: String, ref: String) {
        cache.remove(Key(owner, repo, ref))
    }

    fun clearAll() = cache.clear()
}
