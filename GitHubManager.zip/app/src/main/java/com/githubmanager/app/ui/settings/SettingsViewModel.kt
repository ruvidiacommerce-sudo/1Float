package com.githubmanager.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.githubmanager.app.data.local.AppSettings
import com.githubmanager.app.data.local.RepoTreeCache
import com.githubmanager.app.data.local.SettingsStore
import com.githubmanager.app.data.local.ThemeMode
import com.githubmanager.app.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SettingsScreenState(
    val settings: AppSettings = AppSettings(),
    val username: String? = null,
    val signedOut: Boolean = false,
    val cacheClearedMessage: String? = null
)

class SettingsViewModel(
    private val settingsStore: SettingsStore,
    private val authRepository: AuthRepository,
    private val treeCache: RepoTreeCache,
    username: String?
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsScreenState(username = username))
    val uiState: StateFlow<SettingsScreenState> = _uiState

    init {
        settingsStore.settingsFlow.onEach { s -> _uiState.update { it.copy(settings = s) } }.launchIn(viewModelScope)
    }

    fun setThemeMode(mode: ThemeMode) = viewModelScope.launch { settingsStore.setThemeMode(mode) }
    fun setAutoRefreshRepoList(v: Boolean) = viewModelScope.launch { settingsStore.setAutoRefreshRepoList(v) }
    fun setLoadFilePreviews(v: Boolean) = viewModelScope.launch { settingsStore.setLoadFilePreviews(v) }
    fun setCacheRepoTreeForSearch(v: Boolean) = viewModelScope.launch { settingsStore.setCacheRepoTreeForSearch(v) }
    fun setAutoPollWorkflowRuns(v: Boolean) = viewModelScope.launch { settingsStore.setAutoPollWorkflowRuns(v) }
    fun setPollIntervalSeconds(v: Int) = viewModelScope.launch { settingsStore.setPollIntervalSeconds(v) }
    fun setItemsPerPage(v: Int) = viewModelScope.launch { settingsStore.setItemsPerPage(v) }
    fun setConfirmBeforeDelete(v: Boolean) = viewModelScope.launch { settingsStore.setConfirmBeforeDelete(v) }
    fun setShowHiddenFiles(v: Boolean) = viewModelScope.launch { settingsStore.setShowHiddenFiles(v) }

    fun clearCache() {
        treeCache.clearAll()
        _uiState.update { it.copy(cacheClearedMessage = "Cache cleared.") }
    }

    fun dismissCacheMessage() = _uiState.update { it.copy(cacheClearedMessage = null) }

    fun signOut() {
        viewModelScope.launch {
            authRepository.signOut()
            _uiState.update { it.copy(signedOut = true) }
        }
    }
}
