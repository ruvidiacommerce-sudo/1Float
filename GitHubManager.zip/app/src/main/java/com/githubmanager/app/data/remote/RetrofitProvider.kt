package com.githubmanager.app.data.remote

import com.githubmanager.app.data.local.AccountStore
import com.githubmanager.app.data.model.GitTreeEntry
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import com.google.gson.JsonSerializationContext
import com.google.gson.JsonSerializer
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.lang.reflect.Type
import java.util.concurrent.TimeUnit

private const val BASE_URL = "https://api.github.com/"

/**
 * Gson, by default, omits null fields when serializing. That's normally fine,
 * but the Git Trees API uses an explicit `"sha": null` to mean "delete this
 * path" — a field that's merely absent means something different. This
 * serializer is registered only for [GitTreeEntry] so deletions round-trip
 * correctly, without turning on blanket null-serialization for every other
 * request body in the app (which would risk accidentally clearing fields
 * elsewhere, e.g. in a repo-update request).
 */
private class GitTreeEntrySerializer : JsonSerializer<GitTreeEntry> {
    override fun serialize(src: GitTreeEntry, typeOfSrc: Type, context: JsonSerializationContext): JsonElement {
        val obj = JsonObject()
        obj.addProperty("path", src.path)
        obj.addProperty("mode", src.mode)
        obj.addProperty("type", src.type)
        if (src.sha != null) obj.addProperty("sha", src.sha) else obj.add("sha", JsonNull.INSTANCE)
        return obj
    }
}

object RetrofitProvider {

    private var apiCache: GitHubApiService? = null
    private var plainClientCache: OkHttpClient? = null

    fun gson(): Gson = GsonBuilder()
        .registerTypeAdapter(GitTreeEntry::class.java, GitTreeEntrySerializer())
        .create()

    fun api(accountStore: AccountStore): GitHubApiService {
        return apiCache ?: buildApi(accountStore).also { apiCache = it }
    }

    /** Call after sign-out / sign-in with a different account so cached
     *  clients don't keep using a stale token closure. */
    fun resetCache() {
        apiCache = null
    }

    private fun buildApi(accountStore: AccountStore): GitHubApiService {
        val authInterceptor = AuthInterceptor { accountStore.getCachedToken() }
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC }
        val client = OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(gson()))
            .build()

        return retrofit.create(GitHubApiService::class.java)
    }

    /** No auth header, no redirect-following — used only to read the
     *  Location header off GitHub's artifact-download redirect. */
    fun rawRedirectProbeClient(): OkHttpClient = OkHttpClient.Builder()
        .followRedirects(false)
        .followSslRedirects(false)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    fun plainDownloadClient(): OkHttpClient {
        return plainClientCache ?: OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .build().also { plainClientCache = it }
    }
}
