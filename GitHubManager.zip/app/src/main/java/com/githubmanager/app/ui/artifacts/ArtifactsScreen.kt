@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.githubmanager.app.ui.artifacts

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.githubmanager.app.data.model.Artifact
import com.githubmanager.app.ui.GenericViewModelFactory
import com.githubmanager.app.ui.common.EmptyState
import com.githubmanager.app.ui.common.ErrorView
import com.githubmanager.app.ui.common.LoadingIndicator
import com.githubmanager.app.ui.rememberAppContainer
import com.githubmanager.app.util.formatFileSize
import com.githubmanager.app.util.formatIsoDate

@Composable
fun ArtifactsScreen(owner: String, repo: String) {
    val container = rememberAppContainer()
    val context = LocalContext.current
    val viewModel: ArtifactsViewModel = viewModel(
        key = "artifacts-$owner-$repo",
        factory = GenericViewModelFactory { ArtifactsViewModel(container.artifactRepository, owner, repo) }
    )
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.message) { state.message?.let { snackbarHostState.showSnackbar(it); viewModel.dismissMessage() } }

    Box(Modifier.fillMaxSize()) {
        when {
            state.isLoading -> LoadingIndicator(label = "Loading artifacts…")
            state.error != null && state.artifacts.isEmpty() -> ErrorView(state.error!!, onRetry = viewModel::load)
            state.artifacts.isEmpty() -> EmptyState(
                title = "No artifacts",
                subtitle = "Build outputs uploaded by a workflow run (via actions/upload-artifact) will show up here."
            )
            else -> LazyColumn {
                items(state.artifacts, key = { it.id }) { artifact ->
                    ArtifactRow(
                        artifact = artifact,
                        busy = state.busyArtifactId == artifact.id,
                        onDownload = { viewModel.download(context, artifact) },
                        onDelete = { viewModel.delete(artifact) }
                    )
                    HorizontalDivider()
                }
            }
        }
        SnackbarHost(snackbarHostState, modifier = Modifier.align(Alignment.BottomCenter))
    }
}

@Composable
private fun ArtifactRow(artifact: Artifact, busy: Boolean, onDownload: () -> Unit, onDelete: () -> Unit) {
    ListItem(
        headlineContent = { Text(artifact.name, fontWeight = FontWeight.Medium) },
        supportingContent = {
            Text(
                "${formatFileSize(artifact.sizeInBytes)} • ${formatIsoDate(artifact.createdAt)}" + if (artifact.expired) " • expired" else "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        leadingContent = { Icon(Icons.Filled.Inventory2, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        trailingContent = {
            if (busy) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            } else {
                Row {
                    if (!artifact.expired) {
                        IconButton(onClick = onDownload) { Icon(Icons.Filled.Download, contentDescription = "Download") }
                    }
                    IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                }
            }
        }
    )
}
