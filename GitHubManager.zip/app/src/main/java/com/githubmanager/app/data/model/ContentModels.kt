package com.githubmanager.app.data.model

import com.google.gson.annotations.SerializedName

// --- Contents API (simple single-file operations) ---

data class ContentItem(
    val name: String,
    val path: String,
    val sha: String,
    val size: Long = 0,
    val type: String, // "file", "dir", "symlink", "submodule"
    @SerializedName("download_url") val downloadUrl: String? = null,
    val content: String? = null,
    val encoding: String? = null
)

data class CreateOrUpdateFileRequest(
    val message: String,
    val content: String, // base64
    val sha: String? = null, // required when updating an existing file
    val branch: String? = null
)

data class DeleteFileRequest(
    val message: String,
    val sha: String,
    val branch: String? = null
)

data class FileCommitResponse(
    val content: ContentItem?,
    val commit: CommitInfo
)

data class CommitInfo(
    val sha: String
)

// --- Git Data API (bulk tree operations: move/copy/delete folders, batch upload) ---

data class GitTreeEntry(
    val path: String,
    val mode: String,
    val type: String, // "blob", "tree", "commit"
    val sha: String? = null,
    val size: Long = 0
)

data class GitTree(
    val sha: String,
    val tree: List<GitTreeEntry>,
    val truncated: Boolean = false
)

data class CreateTreeRequest(
    @SerializedName("base_tree") val baseTree: String? = null,
    val tree: List<GitTreeEntry>
)

data class GitBlob(
    val sha: String,
    val content: String? = null,
    val encoding: String? = null,
    val size: Long = 0
)

data class CreateBlobRequest(
    val content: String,
    val encoding: String = "base64"
)

data class CreateCommitRequest(
    val message: String,
    val tree: String,
    val parents: List<String>
)

data class GitCommitResponse(
    val sha: String
)

data class GitCommitDetail(
    val sha: String,
    val tree: GitTreeRef
)

data class GitTreeRef(val sha: String)

data class UpdateRefRequest(
    val sha: String,
    val force: Boolean = false
)

data class CreateRefRequest(
    val ref: String,
    val sha: String
)

data class GitRefObject(
    val sha: String
)

data class GitRef(
    val ref: String,
    @SerializedName("object") val objectRef: GitRefObject
)
