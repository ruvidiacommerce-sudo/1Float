@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.githubmanager.app.ui.repos

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.githubmanager.app.data.model.Repo
import com.githubmanager.app.ui.GenericViewModelFactory
import com.githubmanager.app.ui.common.EmptyState
import com.githubmanager.app.ui.common.ErrorView
import com.githubmanager.app.ui.common.LoadingIndicator
import com.githubmanager.app.ui.common.ProgressDialog
import com.githubmanager.app.ui.rememberAppContainer
import com.githubmanager.app.util.formatIsoDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReposListScreen(
    onOpenRepo: (owner: String, repo: String) -> Unit,
    onOpenSettings: () -> Unit
) {
    val container = rememberAppContainer()
    val viewModel: ReposListViewModel = viewModel(
        factory = GenericViewModelFactory { ReposListViewModel(container.repoRepository, container.settingsStore) }
    )
    val state by viewModel.uiState.collectAsState()
    val username = container.accountStore.getCachedUsername()

    var showCreateDialog by remember { mutableStateOf(false) }
    var actionsSheetRepo by remember { mutableStateOf<Repo?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) { viewModel.onScreenVisible() }
    LaunchedEffect(state.message) {
        state.message?.let { snackbarHostState.showSnackbar(it); viewModel.dismissMessage() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Repositories", fontWeight = FontWeight.SemiBold)
                        if (username != null) {
                            Text("@$username", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = viewModel::refresh) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh") }
                    IconButton(onClick = onOpenSettings) { Icon(Icons.Filled.Settings, contentDescription = "Settings") }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showCreateDialog = true }, icon = { Icon(Icons.Filled.Add, contentDescription = null) }, text = { Text("New repo") })
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = state.query,
                onValueChange = viewModel::onQueryChange,
                placeholder = { Text("Search your repositories") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )

            when {
                state.isLoading && !state.hasLoadedOnce -> LoadingIndicator(label = "Loading repositories…")
                state.error != null && state.repos.isEmpty() -> ErrorView(state.error!!, onRetry = viewModel::refresh)
                state.filteredRepos.isEmpty() && state.hasLoadedOnce -> EmptyState(
                    title = if (state.query.isBlank()) "No repositories yet" else "No matches",
                    subtitle = if (state.query.isBlank()) "Create your first repository to get started." else "Try a different search.",
                    actionLabel = if (state.query.isBlank()) "New repository" else null,
                    onAction = if (state.query.isBlank()) { { showCreateDialog = true } } else null
                )
                else -> LazyColumn(modifier = Modifier.weight(1f)) {
                    items(state.filteredRepos, key = { it.id }) { repo ->
                        RepoRow(
                            repo = repo,
                            busy = state.actionInProgress == repo.fullName,
                            onClick = { onOpenRepo(repo.owner.login, repo.name) },
                            onMoreClick = { actionsSheetRepo = repo }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateRepoDialog(
            onCreate = { name, description, private -> viewModel.createRepo(name, description, private); showCreateDialog = false },
            onDismiss = { showCreateDialog = false }
        )
    }

    actionsSheetRepo?.let { repo ->
        RepoActionsSheet(
            repo = repo,
            onDismiss = { actionsSheetRepo = null },
            onOpen = { onOpenRepo(repo.owner.login, repo.name) },
            onRename = { newName -> viewModel.updateRepo(repo, name = newName, description = null, private = null, archived = null) },
            onEditDescription = { desc -> viewModel.updateRepo(repo, name = null, description = desc, private = null, archived = null) },
            onTogglePrivate = { value -> viewModel.updateRepo(repo, name = null, description = null, private = value, archived = null) },
            onToggleArchived = { value -> viewModel.updateRepo(repo, name = null, description = null, private = null, archived = value) },
            onFork = { viewModel.forkRepo(repo) },
            onDuplicate = { newName, private -> viewModel.duplicateRepo(repo, newName, private) },
            onDelete = { viewModel.deleteRepo(repo) }
        )
    }

    state.duplicateProgress?.let { (done, total) ->
        ProgressDialog(title = "Duplicating repository…", done = done, total = total)
    }
}

@Composable
private fun RepoRow(repo: Repo, busy: Boolean, onClick: () -> Unit, onMoreClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickableRow(onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            if (repo.isPrivate) Icons.Filled.Lock else Icons.Filled.Public,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(repo.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (repo.fork) {
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Filled.ForkRight, contentDescription = "Fork", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                }
                if (repo.archived) {
                    Spacer(Modifier.width(6.dp))
                    Text("archived", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (!repo.description.isNullOrBlank()) {
                Text(repo.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                if (!repo.language.isNullOrBlank()) {
                    Text(repo.language, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(10.dp))
                }
                if (repo.stars > 0) {
                    Icon(Icons.Filled.Star, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(12.dp))
                    Spacer(Modifier.width(2.dp))
                    Text("${repo.stars}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(10.dp))
                }
                if (!repo.updatedAt.isNullOrBlank()) {
                    Text("Updated ${formatIsoDate(repo.updatedAt)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        if (busy) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        } else {
            IconButton(onClick = onMoreClick) { Icon(Icons.Filled.MoreVert, contentDescription = "More actions") }
        }
    }
}

private fun Modifier.clickableRow(onClick: () -> Unit): Modifier = this.then(
    androidx.compose.foundation.clickable(onClick = onClick)
)
