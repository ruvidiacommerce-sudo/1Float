@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.githubmanager.app.ui.repos

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.githubmanager.app.data.model.Repo
import com.githubmanager.app.ui.common.ConfirmDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateRepoDialog(onCreate: (name: String, description: String, private: Boolean) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var private by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New repository") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; error = null },
                    label = { Text("Repository name") },
                    singleLine = true,
                    isError = error != null,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    modifier = Modifier.fillMaxWidth()
                )
                if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description (optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text("Private repository", modifier = Modifier.weight(1f))
                    Switch(checked = private, onCheckedChange = { private = it })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) {
                    error = "Enter a name."
                } else if (!name.matches(Regex("^[A-Za-z0-9._-]+$"))) {
                    error = "Use only letters, numbers, dots, dashes, and underscores."
                } else {
                    onCreate(name.trim(), description.trim(), private)
                }
            }) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RepoActionsSheet(
    repo: Repo,
    onDismiss: () -> Unit,
    onOpen: () -> Unit,
    onRename: (String) -> Unit,
    onEditDescription: (String) -> Unit,
    onTogglePrivate: (Boolean) -> Unit,
    onToggleArchived: (Boolean) -> Unit,
    onFork: () -> Unit,
    onDuplicate: (newName: String, private: Boolean) -> Unit,
    onDelete: () -> Unit
) {
    var showRename by remember { mutableStateOf(false) }
    var showEditDescription by remember { mutableStateOf(false) }
    var showDuplicate by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text(repo.fullName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 20.dp))
            Spacer(Modifier.height(8.dp))

            SheetAction(label = "Open", onClick = { onOpen(); onDismiss() })
            SheetAction(label = "Rename", onClick = { showRename = true })
            SheetAction(label = "Edit description", onClick = { showEditDescription = true })
            SheetAction(label = if (repo.isPrivate) "Make public" else "Make private", onClick = { onTogglePrivate(!repo.isPrivate); onDismiss() })
            SheetAction(label = if (repo.archived) "Unarchive" else "Archive", onClick = { onToggleArchived(!repo.archived); onDismiss() })
            SheetAction(label = "Fork", onClick = { onFork(); onDismiss() })
            SheetAction(label = "Duplicate as new repository", onClick = { showDuplicate = true })
            SheetAction(label = "Delete", destructive = true, onClick = { showDeleteConfirm = true })
        }
    }

    if (showRename) {
        com.githubmanager.app.ui.common.TextInputDialog(
            title = "Rename repository",
            label = "New name",
            initialValue = repo.name,
            validate = { if (it.isBlank()) "Enter a name." else null },
            onConfirm = { onRename(it.trim()); showRename = false; onDismiss() },
            onDismiss = { showRename = false }
        )
    }
    if (showEditDescription) {
        com.githubmanager.app.ui.common.TextInputDialog(
            title = "Edit description",
            label = "Description",
            initialValue = repo.description.orEmpty(),
            onConfirm = { onEditDescription(it.trim()); showEditDescription = false; onDismiss() },
            onDismiss = { showEditDescription = false }
        )
    }
    if (showDuplicate) {
        var newName by remember { mutableStateOf("${repo.name}-copy") }
        var private by remember { mutableStateOf(repo.isPrivate) }
        AlertDialog(
            onDismissRequest = { showDuplicate = false },
            title = { Text("Duplicate repository") },
            text = {
                Column {
                    Text(
                        "Creates an independent copy with its own history — not linked back to ${repo.name}. This can take a while for large repositories.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("New repository name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Private", modifier = Modifier.weight(1f))
                        Switch(checked = private, onCheckedChange = { private = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { onDuplicate(newName.trim(), private); showDuplicate = false; onDismiss() }) { Text("Duplicate") }
            },
            dismissButton = { TextButton(onClick = { showDuplicate = false }) { Text("Cancel") } }
        )
    }
    if (showDeleteConfirm) {
        ConfirmDialog(
            title = "Delete ${repo.name}?",
            message = "This permanently deletes the repository on GitHub, including all its history. This can't be undone.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = { onDelete(); showDeleteConfirm = false; onDismiss() },
            onDismiss = { showDeleteConfirm = false }
        )
    }
}

@Composable
private fun SheetAction(label: String, destructive: Boolean = false, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            label,
            color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp)
        )
    }
}
