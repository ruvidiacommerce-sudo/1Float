package com.githubmanager.app.data.remote

import com.githubmanager.app.data.model.GitHubErrorResponse
import com.google.gson.Gson
import retrofit2.Response
import java.io.IOException

/** A GitHub API call either succeeded with data, or failed with a message
 *  that's already safe to show directly in the UI. */
sealed class ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>()
    data class Error(val message: String, val code: Int? = null) : ApiResult<Nothing>()
}

private val errorGson = Gson()

suspend fun <T> safeApiCall(block: suspend () -> Response<T>): ApiResult<T> {
    return try {
        val response = block()
        if (response.isSuccessful) {
            val body = response.body()
            if (body != null) {
                ApiResult.Success(body)
            } else {
                // 204 No Content and similar — the call succeeded even though
                // there's nothing to deserialize.
                @Suppress("UNCHECKED_CAST")
                ApiResult.Success(Unit as T)
            }
        } else {
            ApiResult.Error(parseError(response), response.code())
        }
    } catch (e: IOException) {
        ApiResult.Error("Couldn't reach GitHub. Check your connection and try again.")
    } catch (e: Exception) {
        ApiResult.Error(e.message ?: "Something went wrong.")
    }
}

private fun parseError(response: Response<*>): String {
    val raw = response.errorBody()?.string()
    val parsed = try {
        if (!raw.isNullOrBlank()) errorGson.fromJson(raw, GitHubErrorResponse::class.java) else null
    } catch (e: Exception) {
        null
    }
    val base = parsed?.message ?: when (response.code()) {
        401 -> "Your token is invalid or has expired. Sign in again from Settings."
        403 -> "GitHub refused this request — you may be missing a token scope, or you've hit a rate limit."
        404 -> "Not found. It may have been deleted, or your token doesn't have access to it."
        409 -> "That conflicts with the current state of the repository. Refresh and try again."
        422 -> "GitHub rejected this request — check the details and try again."
        else -> "Request failed (HTTP ${response.code()})."
    }
    val details = parsed?.errors?.mapNotNull { it.message }?.filter { it.isNotBlank() }?.joinToString("; ")
    return if (!details.isNullOrBlank()) "$base ($details)" else base
}
