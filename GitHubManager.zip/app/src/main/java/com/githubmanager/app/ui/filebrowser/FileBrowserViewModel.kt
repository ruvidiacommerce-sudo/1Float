package com.githubmanager.app.ui.filebrowser

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.githubmanager.app.data.local.RepoTreeCache
import com.githubmanager.app.data.local.SettingsStore
import com.githubmanager.app.data.model.ContentItem
import com.githubmanager.app.data.model.GitTreeEntry
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.repository.ContentsRepository
import com.githubmanager.app.util.ClipEntry
import com.githubmanager.app.util.ClipMode
import com.githubmanager.app.util.ClipboardHolder
import com.githubmanager.app.util.fileNameOf
import com.githubmanager.app.util.joinPath
import com.githubmanager.app.util.parentPath
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FileBrowserUiState(
    val isLoading: Boolean = true,
    val currentPath: String = "",
    val items: List<ContentItem> = emptyList(),
    val error: String? = null,
    val selectionMode: Boolean = false,
    val selectedPaths: Set<String> = emptySet(),
    val searchQuery: String = "",
    val searchResults: List<GitTreeEntry>? = null,
    val isSearching: Boolean = false,
    val message: String? = null,
    val busy: Boolean = false,
    val confirmBeforeDelete: Boolean = true
) {
    val visibleItems: List<ContentItem>
        get() = items.sortedWith(compareBy({ it.type != "dir" }, { it.name.lowercase() }))
}

class FileBrowserViewModel(
    private val contentsRepository: ContentsRepository,
    private val settingsStore: SettingsStore,
    private val treeCache: RepoTreeCache,
    private val owner: String,
    private val repo: String,
    private val branch: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(FileBrowserUiState())
    val uiState: StateFlow<FileBrowserUiState> = _uiState

    init {
        viewModelScope.launch {
            val settings = settingsStore.settingsFlow.first()
            _uiState.update { it.copy(confirmBeforeDelete = settings.confirmBeforeDelete) }
        }
        load()
    }

    fun navigateTo(path: String) {
        _uiState.update { it.copy(currentPath = path, selectionMode = false, selectedPaths = emptySet()) }
        load()
    }

    fun navigateUp(): Boolean {
        val current = _uiState.value.currentPath
        if (current.isBlank()) return false
        navigateTo(parentPath(current))
        return true
    }

    fun refresh() {
        treeCache.invalidate(owner, repo, branch)
        load()
    }

    private fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            when (val result = contentsRepository.listFolder(owner, repo, _uiState.value.currentPath, branch)) {
                is ApiResult.Success -> _uiState.update { it.copy(isLoading = false, items = result.data) }
                is ApiResult.Error -> _uiState.update {
                    // An empty (but existing) folder returns a single-file
                    // response shape from GitHub, not a list — treat that as
                    // "nothing here" rather than a real error where useful,
                    // otherwise just surface it.
                    it.copy(isLoading = false, items = emptyList(), error = result.message)
                }
            }
        }
    }

    // --- Selection mode ---

    fun toggleSelectionMode(startPath: String? = null) {
        _uiState.update {
            val enabling = !it.selectionMode
            it.copy(
                selectionMode = enabling,
                selectedPaths = if (enabling && startPath != null) setOf(startPath) else emptySet()
            )
        }
    }

    fun toggleSelected(path: String) {
        _uiState.update {
            val newSet = if (path in it.selectedPaths) it.selectedPaths - path else it.selectedPaths + path
            it.copy(selectedPaths = newSet, selectionMode = newSet.isNotEmpty())
        }
    }

    fun clearSelection() = _uiState.update { it.copy(selectionMode = false, selectedPaths = emptySet()) }

    // --- Create ---

    fun createFolder(name: String) {
        val path = joinPath(_uiState.value.currentPath, name)
        viewModelScope.launch {
            _uiState.update { it.copy(busy = true) }
            when (val result = contentsRepository.createFolder(owner, repo, path, branch)) {
                is ApiResult.Success -> { _uiState.update { it.copy(busy = false, message = "Folder created.") }; refresh() }
                is ApiResult.Error -> _uiState.update { it.copy(busy = false, error = result.message) }
            }
        }
    }

    // --- Delete ---

    fun deleteItem(item: ContentItem) {
        viewModelScope.launch {
            _uiState.update { it.copy(busy = true) }
            val result = if (item.type == "dir") {
                contentsRepository.deleteFolder(owner, repo, item.path, branch)
            } else {
                contentsRepository.deleteFile(owner, repo, item.path, item.sha, "Delete ${item.path}", branch)
            }
            when (result) {
                is ApiResult.Success -> { _uiState.update { it.copy(busy = false, message = "Deleted.") }; refresh() }
                is ApiResult.Error -> _uiState.update { it.copy(busy = false, error = result.message) }
            }
        }
    }

    fun deleteSelected() {
        val selected = _uiState.value.items.filter { it.path in _uiState.value.selectedPaths }
        viewModelScope.launch {
            _uiState.update { it.copy(busy = true) }
            var lastError: String? = null
            for (item in selected) {
                val result = if (item.type == "dir") {
                    contentsRepository.deleteFolder(owner, repo, item.path, branch)
                } else {
                    contentsRepository.deleteFile(owner, repo, item.path, item.sha, "Delete ${item.path}", branch)
                }
                if (result is ApiResult.Error) lastError = result.message
            }
            _uiState.update { it.copy(busy = false, selectionMode = false, selectedPaths = emptySet(), error = lastError, message = if (lastError == null) "Deleted ${selected.size} item(s)." else null) }
            refresh()
        }
    }

    // --- Rename ---

    fun renameItem(item: ContentItem, newName: String) {
        val newPath = joinPath(parentPath(item.path), newName)
        viewModelScope.launch {
            _uiState.update { it.copy(busy = true) }
            val result = if (item.type == "dir") {
                contentsRepository.moveOrCopyFolder(owner, repo, branch, item.path, newPath, keepOriginal = false)
            } else {
                contentsRepository.moveOrCopySingleFile(owner, repo, branch, item.path, newPath, item.sha, "100644", keepOriginal = false)
            }
            when (result) {
                is ApiResult.Success -> { _uiState.update { it.copy(busy = false, message = "Renamed.") }; refresh() }
                is ApiResult.Error -> _uiState.update { it.copy(busy = false, error = result.message) }
            }
        }
    }

    // --- Cut / copy / paste ---

    fun cutSelected() = putClipboard(ClipMode.CUT)
    fun copySelected() = putClipboard(ClipMode.COPY)

    private fun putClipboard(mode: ClipMode) {
        val selected = _uiState.value.items.filter { it.path in _uiState.value.selectedPaths }
        if (selected.isEmpty()) return
        val entries = selected.map {
            ClipEntry(path = it.path, name = it.name, isFolder = it.type == "dir", sha = if (it.type == "dir") null else it.sha, mode = "100644")
        }
        ClipboardHolder.set(mode, owner, repo, branch, entries)
        clearSelection()
        _uiState.update { it.copy(message = "${entries.size} item(s) ${if (mode == ClipMode.CUT) "cut" else "copied"}.") }
    }

    fun pasteHere() {
        val clip = ClipboardHolder.state.value
        if (clip.isEmpty || clip.owner != owner || clip.repo != repo) {
            _uiState.update { it.copy(error = "Nothing to paste here — cut or copy something first.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(busy = true) }
            val keepOriginal = clip.mode == ClipMode.COPY
            when (val result = contentsRepository.pasteEntries(owner, repo, branch, clip.entries, _uiState.value.currentPath, keepOriginal)) {
                is ApiResult.Success -> {
                    if (!keepOriginal) ClipboardHolder.clear()
                    _uiState.update { it.copy(busy = false, message = "Pasted.") }
                    refresh()
                }
                is ApiResult.Error -> _uiState.update { it.copy(busy = false, error = result.message) }
            }
        }
    }

    // --- Search within repo ---

    fun search(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        if (query.isBlank()) {
            _uiState.update { it.copy(searchResults = null) }
            return
        }
        val cached = treeCache.get(owner, repo, branch)
        if (cached != null) {
            _uiState.update { it.copy(searchResults = cached.filter { e -> e.type == "blob" && e.path.contains(query, ignoreCase = true) }) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSearching = true) }
            val settings = settingsStore.settingsFlow.first()
            when (val result = contentsRepository.searchFilenames(owner, repo, branch, query)) {
                is ApiResult.Success -> {
                    if (settings.cacheRepoTreeForSearch) treeCache.put(owner, repo, branch, result.data)
                    _uiState.update { it.copy(isSearching = false, searchResults = result.data) }
                }
                is ApiResult.Error -> _uiState.update { it.copy(isSearching = false, error = result.message) }
            }
        }
    }

    fun clearSearch() = _uiState.update { it.copy(searchQuery = "", searchResults = null) }

    fun dismissError() = _uiState.update { it.copy(error = null) }
    fun dismissMessage() = _uiState.update { it.copy(message = null) }
}
