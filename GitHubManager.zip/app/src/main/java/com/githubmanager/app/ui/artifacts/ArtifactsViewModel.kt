package com.githubmanager.app.ui.artifacts

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import androidx.core.net.toUri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.githubmanager.app.data.model.Artifact
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.repository.ArtifactRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ArtifactsUiState(
    val isLoading: Boolean = true,
    val artifacts: List<Artifact> = emptyList(),
    val error: String? = null,
    val busyArtifactId: Long? = null,
    val message: String? = null
)

class ArtifactsViewModel(
    private val artifactRepository: ArtifactRepository,
    private val owner: String,
    private val repo: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(ArtifactsUiState())
    val uiState: StateFlow<ArtifactsUiState> = _uiState

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            when (val result = artifactRepository.listArtifacts(owner, repo)) {
                is ApiResult.Success -> _uiState.update { it.copy(isLoading = false, artifacts = result.data) }
                is ApiResult.Error -> _uiState.update { it.copy(isLoading = false, error = result.message) }
            }
        }
    }

    fun delete(artifact: Artifact) {
        viewModelScope.launch {
            _uiState.update { it.copy(busyArtifactId = artifact.id) }
            when (val result = artifactRepository.deleteArtifact(owner, repo, artifact.id)) {
                is ApiResult.Success -> _uiState.update {
                    it.copy(busyArtifactId = null, artifacts = it.artifacts.filterNot { a -> a.id == artifact.id }, message = "Artifact deleted.")
                }
                is ApiResult.Error -> _uiState.update { it.copy(busyArtifactId = null, error = result.message) }
            }
        }
    }

    fun download(context: Context, artifact: Artifact) {
        viewModelScope.launch {
            _uiState.update { it.copy(busyArtifactId = artifact.id) }
            when (val result = artifactRepository.resolveDownloadUrl(owner, repo, artifact.id)) {
                is ApiResult.Success -> {
                    enqueueDownload(context, result.data, "${artifact.name}.zip")
                    _uiState.update { it.copy(busyArtifactId = null, message = "Download started — check your notifications.") }
                }
                is ApiResult.Error -> _uiState.update { it.copy(busyArtifactId = null, error = result.message) }
            }
        }
    }

    private fun enqueueDownload(context: Context, url: String, fileName: String) {
        val request = DownloadManager.Request(url.toUri())
            .setTitle(fileName)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, fileName)
            .setAllowedOverMetered(true)
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
    }

    fun dismissError() = _uiState.update { it.copy(error = null) }
    fun dismissMessage() = _uiState.update { it.copy(message = null) }
}
