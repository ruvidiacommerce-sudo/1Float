@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.githubmanager.app.ui.editor

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.githubmanager.app.ui.GenericViewModelFactory
import com.githubmanager.app.ui.common.ConfirmDialog
import com.githubmanager.app.ui.common.LoadingIndicator
import com.githubmanager.app.ui.common.TextInputDialog
import com.githubmanager.app.ui.rememberAppContainer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileEditorScreen(
    owner: String,
    repo: String,
    branch: String,
    path: String,
    sha: String?,
    isNewFile: Boolean,
    onDone: () -> Unit
) {
    val container = rememberAppContainer()
    val viewModel: FileEditorViewModel = viewModel(
        key = "editor-$owner-$repo-$branch-$path",
        factory = GenericViewModelFactory {
            FileEditorViewModel(container.contentsRepository, owner, repo, branch, path, isNewFile, sha)
        }
    )
    val state by viewModel.uiState.collectAsState()
    var showCommitDialog by remember { mutableStateOf(false) }
    var showDiscardConfirm by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    val fileName = path.substringAfterLast('/')

    fun handleBack() {
        if (state.isDirty) showDiscardConfirm = true else onDone()
    }

    BackHandler { handleBack() }

    LaunchedEffect(state.saved) {
        if (state.saved) {
            snackbarHostState.showSnackbar("Saved.")
            viewModel.consumeSaved()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(fileName, fontWeight = FontWeight.SemiBold) },
                navigationIcon = { IconButton(onClick = ::handleBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } },
                actions = {
                    IconButton(onClick = { showCommitDialog = true }, enabled = state.isDirty && !state.isSaving) {
                        if (state.isSaving) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.Save, contentDescription = "Save")
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when {
                state.isLoading -> LoadingIndicator(label = "Loading file…")
                state.error != null -> Text(state.error!!, modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error)
                state.isBinaryOrTooLarge -> Text(
                    "This file doesn't look like text (or it's too large to edit here). Editing is only supported for text files.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                else -> OutlinedTextField(
                    value = state.text,
                    onValueChange = viewModel::onTextChange,
                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrect = false),
                    modifier = Modifier.fillMaxSize().padding(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = MaterialTheme.colorScheme.surface,
                        focusedBorderColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        }
    }

    if (showCommitDialog) {
        TextInputDialog(
            title = "Commit message",
            label = "Describe your change",
            initialValue = if (isNewFile) "Create $fileName" else "Update $fileName",
            confirmLabel = "Commit",
            onConfirm = { message -> viewModel.save(message); showCommitDialog = false },
            onDismiss = { showCommitDialog = false }
        )
    }

    if (showDiscardConfirm) {
        ConfirmDialog(
            title = "Discard changes?",
            message = "You have unsaved edits to $fileName.",
            confirmLabel = "Discard",
            destructive = true,
            onConfirm = { showDiscardConfirm = false; onDone() },
            onDismiss = { showDiscardConfirm = false }
        )
    }
}
