package com.githubmanager.app.ui.workflows

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.githubmanager.app.data.local.SettingsStore
import com.githubmanager.app.data.model.Workflow
import com.githubmanager.app.data.model.WorkflowRun
import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.repository.ContentsRepository
import com.githubmanager.app.data.repository.WorkflowRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class WorkflowsUiState(
    val isLoading: Boolean = true,
    val workflows: List<Workflow> = emptyList(),
    val error: String? = null,
    val busyWorkflowId: Long? = null,
    val selectedWorkflow: Workflow? = null,
    val runs: List<WorkflowRun> = emptyList(),
    val isLoadingRuns: Boolean = false,
    val busyRunId: Long? = null,
    val message: String? = null
)

class WorkflowsViewModel(
    private val workflowRepository: WorkflowRepository,
    private val contentsRepository: ContentsRepository,
    private val settingsStore: SettingsStore,
    private val owner: String,
    private val repo: String,
    private val branch: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(WorkflowsUiState())
    val uiState: StateFlow<WorkflowsUiState> = _uiState

    private var pollJob: kotlinx.coroutines.Job? = null

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            when (val result = workflowRepository.listWorkflows(owner, repo)) {
                is ApiResult.Success -> _uiState.update { it.copy(isLoading = false, workflows = result.data) }
                is ApiResult.Error -> _uiState.update { it.copy(isLoading = false, error = result.message) }
            }
        }
    }

    fun setEnabled(workflow: Workflow, enabled: Boolean) {
        viewModelScope.launch {
            _uiState.update { it.copy(busyWorkflowId = workflow.id) }
            when (val result = workflowRepository.setEnabled(owner, repo, workflow.id, enabled)) {
                is ApiResult.Success -> {
                    _uiState.update { it.copy(busyWorkflowId = null, message = if (enabled) "Workflow enabled." else "Workflow disabled.") }
                    load()
                }
                is ApiResult.Error -> _uiState.update { it.copy(busyWorkflowId = null, error = result.message) }
            }
        }
    }

    fun dispatch(workflow: Workflow, ref: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(busyWorkflowId = workflow.id) }
            when (val result = workflowRepository.dispatch(owner, repo, workflow.id, ref)) {
                is ApiResult.Success -> _uiState.update { it.copy(busyWorkflowId = null, message = "Run triggered.") }
                is ApiResult.Error -> _uiState.update { it.copy(busyWorkflowId = null, error = result.message) }
            }
        }
    }

    fun deleteWorkflowFile(workflow: Workflow) {
        viewModelScope.launch {
            _uiState.update { it.copy(busyWorkflowId = workflow.id) }
            val fileResult = contentsRepository.getFile(owner, repo, workflow.path, branch)
            if (fileResult is ApiResult.Error) {
                _uiState.update { it.copy(busyWorkflowId = null, error = fileResult.message) }
                return@launch
            }
            val sha = (fileResult as ApiResult.Success).data.sha
            when (val result = workflowRepository.deleteWorkflowFile(owner, repo, workflow.path, sha, branch)) {
                is ApiResult.Success -> {
                    _uiState.update { it.copy(busyWorkflowId = null, message = "Workflow deleted.") }
                    load()
                }
                is ApiResult.Error -> _uiState.update { it.copy(busyWorkflowId = null, error = result.message) }
            }
        }
    }

    fun openRuns(workflow: Workflow) {
        _uiState.update { it.copy(selectedWorkflow = workflow, runs = emptyList()) }
        loadRuns()
        startPollingIfEnabled()
    }

    fun closeRuns() {
        pollJob?.cancel()
        _uiState.update { it.copy(selectedWorkflow = null, runs = emptyList()) }
    }

    fun loadRuns() {
        val workflow = _uiState.value.selectedWorkflow ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingRuns = true) }
            when (val result = workflowRepository.listRuns(owner, repo, workflow.id)) {
                is ApiResult.Success -> _uiState.update { it.copy(isLoadingRuns = false, runs = result.data) }
                is ApiResult.Error -> _uiState.update { it.copy(isLoadingRuns = false, error = result.message) }
            }
        }
    }

    private fun startPollingIfEnabled() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            val settings = settingsStore.settingsFlow.first()
            if (!settings.autoPollWorkflowRuns) return@launch
            while (isActive) {
                delay(settings.pollIntervalSeconds.coerceAtLeast(5) * 1000L)
                if (_uiState.value.selectedWorkflow != null) loadRuns() else break
            }
        }
    }

    fun cancelRun(run: WorkflowRun) {
        viewModelScope.launch {
            _uiState.update { it.copy(busyRunId = run.id) }
            when (val result = workflowRepository.cancelRun(owner, repo, run.id)) {
                is ApiResult.Success -> { _uiState.update { it.copy(busyRunId = null, message = "Cancelling…") }; loadRuns() }
                is ApiResult.Error -> _uiState.update { it.copy(busyRunId = null, error = result.message) }
            }
        }
    }

    fun deleteRun(run: WorkflowRun) {
        viewModelScope.launch {
            _uiState.update { it.copy(busyRunId = run.id) }
            when (val result = workflowRepository.deleteRun(owner, repo, run.id)) {
                is ApiResult.Success -> {
                    _uiState.update { it.copy(busyRunId = null, runs = it.runs.filterNot { r -> r.id == run.id }, message = "Run deleted.") }
                }
                is ApiResult.Error -> _uiState.update { it.copy(busyRunId = null, error = result.message) }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        pollJob?.cancel()
    }

    fun dismissError() = _uiState.update { it.copy(error = null) }
    fun dismissMessage() = _uiState.update { it.copy(message = null) }
}
