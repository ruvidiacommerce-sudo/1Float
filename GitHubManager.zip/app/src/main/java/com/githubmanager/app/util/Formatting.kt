package com.githubmanager.app.util

import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlin.math.log10
import kotlin.math.pow

/** Percent-encodes each path segment individually while preserving the `/`
 *  separators GitHub's contents/tree endpoints expect (Retrofit's `@Path`
 *  is set to `encoded = true` for these, so this is the only place that
 *  encoding happens). */
fun encodeGitPath(path: String): String {
    val trimmed = path.trim('/')
    if (trimmed.isEmpty()) return ""
    return trimmed.split("/").joinToString("/") { segment ->
        URLEncoder.encode(segment, "UTF-8").replace("+", "%20")
    }
}

fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (log10(bytes.toDouble()) / log10(1024.0)).toInt().coerceIn(0, units.size - 1)
    val value = bytes / 1024.0.pow(digitGroups.toDouble())
    return if (digitGroups == 0) "$bytes B" else String.format(Locale.US, "%.1f %s", value, units[digitGroups])
}

private val isoParser = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
    timeZone = TimeZone.getTimeZone("UTC")
}
private val displayFormat = SimpleDateFormat("MMM d, yyyy 'at' h:mm a", Locale.US)

fun formatIsoDate(iso: String?): String {
    if (iso.isNullOrBlank()) return ""
    return try {
        val date = isoParser.parse(iso) ?: return iso
        displayFormat.format(date)
    } catch (e: Exception) {
        iso
    }
}

/** Joins a folder path and a name, handling the root ("") case cleanly. */
fun joinPath(folder: String, name: String): String =
    if (folder.isBlank()) name else "${folder.trimEnd('/')}/$name"

fun parentPath(path: String): String {
    val trimmed = path.trim('/')
    val idx = trimmed.lastIndexOf('/')
    return if (idx == -1) "" else trimmed.substring(0, idx)
}

fun fileNameOf(path: String): String = path.trim('/').substringAfterLast('/')
