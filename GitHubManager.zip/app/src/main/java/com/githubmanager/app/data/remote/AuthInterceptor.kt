package com.githubmanager.app.data.remote

import okhttp3.Interceptor
import okhttp3.Response

/** Adds the auth header and GitHub's required API headers to every request.
 *  [tokenProvider] is a plain synchronous lookup (a cached in-memory value),
 *  since interceptors run on whatever thread made the call and shouldn't
 *  block on disk I/O for something this hot-path. */
class AuthInterceptor(private val tokenProvider: () -> String?) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val token = tokenProvider()
        val request = chain.request().newBuilder()
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28")
            .apply { if (!token.isNullOrBlank()) header("Authorization", "Bearer $token") }
            .build()
        return chain.proceed(request)
    }
}
