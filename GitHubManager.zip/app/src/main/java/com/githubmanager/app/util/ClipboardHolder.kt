package com.githubmanager.app.util

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ClipMode { CUT, COPY }

data class ClipEntry(
    val path: String,
    val name: String,
    val isFolder: Boolean,
    val sha: String?, // null for folders, since a folder has no single sha
    val mode: String  // git file mode, e.g. "100644"
)

data class ClipboardState(
    val mode: ClipMode? = null,
    val owner: String? = null,
    val repo: String? = null,
    val branch: String? = null,
    val entries: List<ClipEntry> = emptyList()
) {
    val isEmpty: Boolean get() = entries.isEmpty()
}

/** A tiny app-wide singleton so cut/copy survives navigating into a
 *  different folder before pasting — deliberately simple since it only ever
 *  holds one pending operation at a time, same as a real clipboard. */
object ClipboardHolder {
    private val _state = MutableStateFlow(ClipboardState())
    val state: StateFlow<ClipboardState> = _state.asStateFlow()

    fun set(mode: ClipMode, owner: String, repo: String, branch: String, entries: List<ClipEntry>) {
        _state.value = ClipboardState(mode, owner, repo, branch, entries)
    }

    fun clear() {
        _state.value = ClipboardState()
    }
}
