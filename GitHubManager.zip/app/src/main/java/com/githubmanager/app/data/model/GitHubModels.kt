package com.githubmanager.app.data.model

import com.google.gson.annotations.SerializedName

data class GitHubUser(
    val login: String,
    val id: Long,
    @SerializedName("avatar_url") val avatarUrl: String?,
    val name: String?,
    @SerializedName("public_repos") val publicRepos: Int = 0
)

data class Owner(
    val login: String,
    @SerializedName("avatar_url") val avatarUrl: String? = null
)

data class Repo(
    val id: Long,
    val name: String,
    @SerializedName("full_name") val fullName: String,
    val owner: Owner,
    @SerializedName("private") val isPrivate: Boolean,
    val description: String?,
    @SerializedName("default_branch") val defaultBranch: String = "main",
    @SerializedName("html_url") val htmlUrl: String,
    val fork: Boolean = false,
    @SerializedName("updated_at") val updatedAt: String? = null,
    @SerializedName("pushed_at") val pushedAt: String? = null,
    val size: Long = 0,
    @SerializedName("stargazers_count") val stars: Int = 0,
    val language: String? = null,
    val archived: Boolean = false
)

data class CreateRepoRequest(
    val name: String,
    val description: String? = null,
    @SerializedName("private") val isPrivate: Boolean = true,
    @SerializedName("auto_init") val autoInit: Boolean = true
)

data class UpdateRepoRequest(
    val name: String? = null,
    val description: String? = null,
    @SerializedName("private") val isPrivate: Boolean? = null,
    @SerializedName("default_branch") val defaultBranch: String? = null,
    val archived: Boolean? = null
)

data class Branch(
    val name: String,
    val commit: BranchCommitRef
)

data class BranchCommitRef(
    val sha: String
)

data class GitHubErrorResponse(
    val message: String?,
    val errors: List<GitHubFieldError>? = null,
    @SerializedName("documentation_url") val documentationUrl: String? = null
)

data class GitHubFieldError(
    val resource: String? = null,
    val field: String? = null,
    val code: String? = null,
    val message: String? = null
)
