package com.githubmanager.app.data.repository

import com.githubmanager.app.data.remote.ApiResult
import com.githubmanager.app.data.remote.GitHubApiService
import com.githubmanager.app.util.joinPath

/** Pushes a batch of picked files (from a folder, or a zip already unzipped
 *  in memory) into a target folder of a new or existing repo, in one commit. */
class UploadRepository(private val api: GitHubApiService) {

    private val treeEngine = GitTreeEngine(api)

    suspend fun uploadFiles(
        owner: String,
        repo: String,
        branch: String,
        targetFolder: String,
        files: List<PendingFile>,
        commitMessage: String,
        onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }
    ): ApiResult<String> {
        val prefixed = if (targetFolder.isBlank()) files else files.map {
            PendingFile(path = joinPath(targetFolder, it.path), bytes = it.bytes)
        }
        return treeEngine.pushFiles(owner, repo, branch, commitMessage, prefixed, onProgress)
    }
}
