package com.githubmanager.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import com.githubmanager.app.AppContainer
import com.githubmanager.app.GitHubManagerApp

@Composable
fun rememberAppContainer(): AppContainer {
    val context = LocalContext.current
    return (context.applicationContext as GitHubManagerApp).container
}

/** Builds a ViewModel from a plain lambda instead of requiring a
 *  no-argument constructor — lets every screen wire its ViewModel to the
 *  exact repositories it needs from [AppContainer] without a DI framework. */
class GenericViewModelFactory(private val create: () -> ViewModel) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T = create() as T
}
