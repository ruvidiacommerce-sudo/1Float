@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.githubmanager.app.ui.repodetail

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.githubmanager.app.ui.GenericViewModelFactory
import com.githubmanager.app.ui.artifacts.ArtifactsScreen
import com.githubmanager.app.ui.common.ErrorView
import com.githubmanager.app.ui.common.LoadingIndicator
import com.githubmanager.app.ui.filebrowser.FileBrowserScreen
import com.githubmanager.app.ui.rememberAppContainer
import com.githubmanager.app.ui.workflows.WorkflowsScreen

private enum class RepoTab(val label: String) { FILES("Files"), WORKFLOWS("Actions"), ARTIFACTS("Artifacts") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RepoDetailScreen(
    owner: String,
    repo: String,
    onBack: () -> Unit,
    onOpenFile: (path: String, branch: String, sha: String) -> Unit,
    onNewFile: (path: String, branch: String) -> Unit,
    onUpload: (targetPath: String, branch: String) -> Unit
) {
    val container = rememberAppContainer()
    val viewModel: RepoDetailViewModel = viewModel(
        key = "repo-detail-$owner-$repo",
        factory = GenericViewModelFactory { RepoDetailViewModel(container.repoRepository, owner, repo) }
    )
    val state by viewModel.uiState.collectAsState()
    var tab by remember { mutableStateOf(RepoTab.FILES) }
    var showBranchMenu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = { Text(repo) },
                    navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } },
                    actions = {
                        if (state.branches.isNotEmpty()) {
                            Box {
                                TextButton(onClick = { showBranchMenu = true }) { Text(state.selectedBranch) }
                                DropdownMenu(expanded = showBranchMenu, onDismissRequest = { showBranchMenu = false }) {
                                    state.branches.forEach { branch ->
                                        DropdownMenuItem(text = { Text(branch.name) }, onClick = { viewModel.selectBranch(branch.name); showBranchMenu = false })
                                    }
                                }
                            }
                        }
                    }
                )
                if (state.repo != null) {
                    TabRow(selectedTabIndex = tab.ordinal) {
                        RepoTab.entries.forEach { t ->
                            Tab(selected = tab == t, onClick = { tab = t }, text = { Text(t.label) })
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when {
                state.isLoading -> LoadingIndicator(label = "Loading repository…")
                state.error != null && state.repo == null -> ErrorView(state.error!!, onRetry = viewModel::load)
                state.repo != null -> {
                    val branch = state.selectedBranch
                    when (tab) {
                        RepoTab.FILES -> FileBrowserScreen(
                            owner = owner,
                            repo = repo,
                            branch = branch,
                            onOpenFile = { path, sha -> onOpenFile(path, branch, sha) },
                            onNewFile = { path -> onNewFile(path, branch) },
                            onUploadHere = { targetPath -> onUpload(targetPath, branch) }
                        )
                        RepoTab.WORKFLOWS -> WorkflowsScreen(owner, repo, branch)
                        RepoTab.ARTIFACTS -> ArtifactsScreen(owner, repo)
                    }
                }
            }
        }
    }
}
