@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.githubmanager.app.ui.upload

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.githubmanager.app.ui.GenericViewModelFactory
import com.githubmanager.app.ui.common.ProgressDialog
import com.githubmanager.app.ui.rememberAppContainer
import com.githubmanager.app.util.formatFileSize

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadScreen(
    owner: String,
    repo: String,
    branch: String,
    targetPath: String,
    onDone: () -> Unit
) {
    val container = rememberAppContainer()
    val context = LocalContext.current
    val viewModel: UploadViewModel = viewModel(
        factory = GenericViewModelFactory { UploadViewModel(container.uploadRepository, container.repoRepository, owner, repo, branch, targetPath) }
    )
    val state by viewModel.uiState.collectAsState()

    val zipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.pickZip(context, it) }
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri?.let { viewModel.pickFolder(context, it) }
    }
    val filesPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) viewModel.pickIndividualFiles(context, uris)
    }

    LaunchedEffect(state.done) { if (state.done) onDone() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.isNewRepoMode) "Upload to new repository" else "Upload here", fontWeight = FontWeight.SemiBold) },
                navigationIcon = { IconButton(onClick = onDone) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(16.dp)
        ) {
            if (state.isNewRepoMode) {
                OutlinedTextField(
                    value = state.newRepoName,
                    onValueChange = viewModel::onNewRepoNameChange,
                    label = { Text("New repository name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Private repository", modifier = Modifier.weight(1f))
                    Switch(checked = state.newRepoPrivate, onCheckedChange = viewModel::onNewRepoPrivateChange)
                }
                Spacer(Modifier.height(16.dp))
            } else {
                OutlinedTextField(
                    value = state.targetPath,
                    onValueChange = viewModel::onTargetPathChange,
                    label = { Text("Upload into folder (blank = repo root)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
            }

            Text("Choose what to upload", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PickerCard(Icons.Filled.FolderZip, "Zip file", Modifier.weight(1f)) { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed")) }
                PickerCard(Icons.Filled.Folder, "Folder", Modifier.weight(1f)) { folderPicker.launch(null) }
                PickerCard(Icons.Filled.InsertDriveFile, "File(s)", Modifier.weight(1f)) { filesPicker.launch(arrayOf("*/*")) }
            }

            if (state.isReading) {
                Spacer(Modifier.height(16.dp))
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text("Reading files…", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            if (state.pickedFiles.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(state.pickedSourceLabel, style = MaterialTheme.typography.titleSmall)
                        Text("${formatFileSize(state.totalBytes)} total", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = state.commitMessage,
                    onValueChange = viewModel::onCommitMessageChange,
                    label = { Text("Commit message (optional)") },
                    placeholder = { Text("Add ${state.pickedFiles.size} file(s)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = viewModel::upload,
                    enabled = !state.isUploading,
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text(if (state.isNewRepoMode) "Create repository and push" else "Push to repository")
                }
            }

            if (state.error != null) {
                Spacer(Modifier.height(12.dp))
                Text(state.error!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    state.progress?.let { (done, total) ->
        if (state.isUploading) {
            ProgressDialog(title = "Uploading…", done = done, total = total)
        }
    }
}

@Composable
private fun PickerCard(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(6.dp))
            Text(label, style = MaterialTheme.typography.labelMedium)
        }
    }
}
