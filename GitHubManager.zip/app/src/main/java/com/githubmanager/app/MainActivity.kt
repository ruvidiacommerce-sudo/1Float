package com.githubmanager.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.githubmanager.app.data.local.AppSettings
import com.githubmanager.app.ui.common.LoadingIndicator
import com.githubmanager.app.ui.navigation.GitHubManagerNavGraph
import com.githubmanager.app.ui.navigation.Routes
import com.githubmanager.app.ui.theme.GitHubManagerTheme

/**
 * The account cache is warmed asynchronously from Application.onCreate — a
 * fire-and-forget coroutine launch, since Application.onCreate can't suspend.
 * Deciding the start destination synchronously here would race that, so
 * instead this awaits it explicitly before picking Login vs. the repo list.
 * It's a near-instant local read in practice, but doing it properly avoids
 * an intermittent, hard-to-reproduce "signed-in user bounced back to login"
 * bug on a slower cold start.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val container = (application as GitHubManagerApp).container

        setContent {
            val settings by container.settingsStore.settingsFlow.collectAsState(initial = AppSettings())
            GitHubManagerTheme(themeMode = settings.themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    var startDestination by remember { mutableStateOf<String?>(null) }
                    LaunchedEffect(Unit) {
                        container.accountStore.initialize()
                        startDestination = if (container.accountStore.isSignedIn()) Routes.REPOS else Routes.LOGIN
                    }
                    val destination = startDestination
                    if (destination == null) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { LoadingIndicator() }
                    } else {
                        GitHubManagerNavGraph(startDestination = destination)
                    }
                }
            }
        }
    }
}
