# GitHub Manager

A native Android app (Kotlin + Jetpack Compose) for managing GitHub directly
from your phone: repositories, files and folders, workflows, and artifacts —
with a real file-manager-style interface (breadcrumbs, cut/copy/paste,
multi-select, search-by-filename) instead of a cut-down mobile web view.

This project is built **entirely by GitHub Actions**. You never need a
computer, Android Studio, or the Android SDK — GitHub's own servers compile
the APK for you, and you download the finished file from the workflow run.

---

## What the app can do

- **Repositories** — list, create, rename, edit description, make
  private/public, archive, fork, delete, and **duplicate** (a true
  independent copy, not just a fork).
- **Files & folders** — create, edit (plain-text editor with commit
  messages), delete, rename, and **cut/copy/paste** — including whole
  folders, multi-select, and moving things between folders. Everything
  routes through GitHub's Git Data API so a folder move/copy/delete is one
  commit, not one API call per file.
- **Upload from your device** — pick a single file, an entire folder, or a
  `.zip` (unzipped on-device, then pushed in one commit) — into a new repo
  or an existing one.
- **Workflows** — enable/disable, trigger a run (`workflow_dispatch`),
  delete, and browse run history (cancel/delete a run, open full logs on
  github.com).
- **Artifacts** — list, download (via the system Download Manager), delete.
- **Settings** — turn off auto-refresh, previews, background polling, and
  more, to cut down on unnecessary network calls; theme; confirm-before-
  delete; items-per-page.
- Quick navigation — tap the repo name in the breadcrumb bar to jump
  straight back to the root from anywhere, or search the whole repo by
  filename.

Sign-in is a GitHub **username + personal access token**, entered directly
in the app (Settings screen shows a shortcut to create a correctly-scoped
token). The token is encrypted on-device with a key held in the Android
Keystore and only ever sent to `api.github.com`.

---

## Setup — from a phone, no computer needed

The one genuinely awkward part of "build an app with no computer" is getting
a *multi-file, multi-folder* project into a fresh repo, since phone browsers
generally can't drag-and-drop a whole folder. This project sidesteps that:
you upload **one zip file**, and a small one-time GitHub Actions workflow
unzips it *inside GitHub's own servers* for you.

1. **Create a new repository** on GitHub (public or private, doesn't
   matter). Leave it empty — don't add a README.

2. **Add the bootstrap workflow file by hand** (this one file has to go in
   first, before the zip, so GitHub knows the workflow exists):
   - On the repo page: **Add file → Create new file**.
   - For the filename, type exactly: `.github/workflows/bootstrap-unzip.yml`
   - Paste in the contents of `.github/workflows/bootstrap-unzip.yml` from
     this project (open it in the file list below, or unzip the download
     locally if you do have a computer handy for this one step).
   - Commit directly to the default branch.

3. **Upload the zip**: **Add file → Upload files** → pick the
   `GitHubManager.zip` you downloaded here → commit. (Uploading one file is
   supported by every browser — this step doesn't need folder support.)

4. **Run the bootstrap workflow**: go to the **Actions** tab →
   **Bootstrap - Unzip Project** → **Run workflow** → Run. Wait for the
   green check. Your repo now has the full project, including the real
   build workflow.

5. **Build the APK**: still in the **Actions** tab, you'll now see
   **Build APK** listed. Open it → **Run workflow** → Run (it will also run
   automatically on every future push). This takes a few minutes the first
   time.

6. **Download it**: once the run finishes, open it and scroll to
   **Artifacts** → download `GitHubManager-debug-apk`. It's a zip containing
   one `.apk` file.

7. **Install it**: on your phone, open the downloaded zip, extract the
   `.apk`, and tap it. You'll need to allow "install unknown apps" for your
   browser or file manager the first time — Android will prompt you.

8. **Sign in**: open the app, enter your GitHub username and a personal
   access token. Tap **Create a token on GitHub** for a shortcut straight to
   GitHub's token page with the right permissions pre-selected:
   - `repo` — read/write your repositories
   - `workflow` — update workflow files and trigger runs
   - `delete_repo` — only needed if you want to delete repos from the app

### If your browser *can* upload a whole folder

Some desktop browsers support dragging an entire folder onto GitHub's
"Upload files" page, and `github.dev` (press `.` on any repo page) lets you
create nested files/folders directly in a VS Code-style editor. If you have
occasional access to either, you can skip the zip/bootstrap dance and just
add all the files directly — the bootstrap workflow is purely a convenience
for phone-only setups, not a requirement.

---

## Updating the app later

Since everything lives in the repo, iterating is just: edit the code (via
`github.dev`, GitHub's web editor, or by asking an AI assistant to make the
change and push it for you), then either push to `main` (the build runs
automatically) or trigger **Build APK** manually from the Actions tab.
Download the new APK from that run's artifacts and install it over the old
one — updates install cleanly without uninstalling first, because every
build is signed with the same key (a `debug.keystore` file the workflow
generates once and commits to the repo; see the comments in
`.github/workflows/build-apk.yml` for why).

---

## Project structure

```
GitHubManager/
├── .github/workflows/
│   ├── bootstrap-unzip.yml   # one-time: unzip project.zip into place
│   └── build-apk.yml         # the real CI: builds & uploads the APK
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── res/               # theme, adaptive icon (as vector drawables — no binary assets)
│       └── java/com/githubmanager/app/
│           ├── data/
│           │   ├── model/       # GitHub API response/request models
│           │   ├── remote/      # Retrofit service, auth, error handling
│           │   ├── local/       # encrypted account store, settings, tree cache
│           │   └── repository/  # business logic, incl. GitTreeEngine
│           ├── ui/              # one package per screen (Compose)
│           └── util/            # zip/folder reading, formatting, clipboard
├── gradle/libs.versions.toml    # every dependency version, one place
├── build.gradle.kts / settings.gradle.kts
└── README.md
```

### Why it's built the way it is

- **No Hilt/Dagger, no KSP** — dependencies are wired by hand in
  `AppContainer.kt`. With no local machine to debug a bad annotation-
  processor upgrade on, fewer moving parts in the build is worth more than
  the convenience of a DI framework.
- **AGP 8.x / Kotlin 2.1, not the newest majors** — at the time this was
  generated, AGP 9.0 had just introduced a new "built-in Kotlin" build
  model. That's unfamiliar enough territory that it's the wrong place to
  take a risk on a build nobody can debug interactively — so this targets
  the well-established AGP 8 / Gradle 8 line instead. It'll keep working
  indefinitely; nothing here "expires."
- **The Git Data API, not one-call-per-file** — folder move/copy/delete and
  bulk uploads build a single tree + commit + ref update, reusing existing
  blob shas wherever content doesn't change. This is what keeps a folder
  operation to a handful of API calls instead of hitting GitHub's rate
  limit on a medium-sized project.
- **Gson, not kotlinx.serialization** — for the same reliability reason as
  the AGP choice: it's the more boring, more predictable option.

---

## Known scope

This covers everything asked for, but a few things are intentionally kept
simple rather than fully reimplemented:

- The file editor is plain text (no syntax highlighting) — fine for code,
  configs, and docs, but there's no image/binary preview.
- Workflow run detail shows status/conclusion/branch/time and lets you
  cancel or delete a run; for full step-by-step logs it opens the run on
  github.com in your browser rather than reimplementing GitHub's log viewer.
- Sign-in is a personal access token, not GitHub's OAuth device flow — one
  fewer setup step (no separate OAuth App to register), at the cost of
  managing your own token's lifetime.
- If a specific dependency version in `gradle/libs.versions.toml` is ever
  superseded and Gradle can't resolve it, the CI log will name the exact
  missing artifact — bump that one version number (check the library's page
  on `mvnrepository.com`) and re-run.

Everything else — the full repo/file/folder/workflow/artifact management,
cut/copy/paste, zip and folder upload to new or existing repos, and the
settings screen's data-saving toggles — is fully implemented and wired to
real GitHub API calls, not placeholders.
