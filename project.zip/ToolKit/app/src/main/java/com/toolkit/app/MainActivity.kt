package com.toolkit.app

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this)
        tv.text = "ToolKit — Stage 1 build OK"
        tv.textSize = 20f
        tv.setPadding(48, 96, 48, 48)
        setContentView(tv)
    }
}
